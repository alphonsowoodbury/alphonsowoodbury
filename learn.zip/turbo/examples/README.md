# Turbo Examples

This directory contains example pipeline specification JSON files that demonstrate various Turbo features.

## Available Examples

### customer-analytics.json
A batch analytics pipeline that:
- Reads customer data from S3
- Filters to last 30 days
- Aggregates spending metrics by customer and product category
- Writes results to Redshift
- Includes environment-specific overrides

### Usage

To generate pipeline files from any example:

```bash
turbo generate examples/customer-analytics.json
```

## JSON Specification Structure

Each pipeline specification should include:

```json
{
  "name": "pipeline-name",           // Required: Unique pipeline identifier
  "description": "...",              // Pipeline description
  "type": "batch|streaming",         // Pipeline type (default: batch)
  "schedule": "cron expression",     // For batch pipelines
  "source": { ... },                 // Source configuration
  "destination": { ... },            // Destination configuration
  "transformations": [ ... ],        // Optional: Data transformations
  "dev_overrides": { ... },         // Optional: Dev environment overrides
  "staging_overrides": { ... },     // Optional: Staging overrides
  "prod_overrides": { ... }         // Optional: Production overrides
}
```

## Creating Your Own Pipeline Specification

1. Copy one of the example files
2. Modify the configuration to match your pipeline needs
3. Run `turbo generate your-pipeline.json`
4. Review the generated files in your DPL repository

## Best Practices

- Use descriptive pipeline names (kebab-case)
- Include meaningful descriptions
- Define environment-specific overrides for safety
- Keep transformation logic simple and testable
- Version your pipeline specifications alongside your code