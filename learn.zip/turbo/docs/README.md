# Turbo Documentation

Welcome to the Turbo documentation! This guide will help you understand the architecture, design principles, and development practices behind Turbo.

## Documentation Structure

### Core Documentation

- **[Architecture](ARCHITECTURE.md)** - System architecture and component design
- **[Design Document](DESIGN.md)** - Product design, user personas, and feature specifications
- **[Engineering Principles](ENGINEERING_PRINCIPLES.md)** - Coding standards and best practices
- **[Testing Strategy](TESTING_STRATEGY.md)** - Comprehensive testing approach
- **[User Guide](USER_GUIDE.md)** - Detailed usage instructions and examples
- **[Whitepaper](WHITEPAPER.md)** - Technical deep-dive and implementation details

### Learning Go

- **[Go Learning Path](go/README.md)** - Structured Go learning resources
- **[Getting Started](go/01-getting-started.md)** - Go basics for beginners
- **[Language Fundamentals](go/02-language-fundamentals.md)** - Core Go concepts
- **[Effective Go](go/03-effective-go.md)** - Idiomatic Go patterns
- **[Error Handling](go/04-error-handling.md)** - Go error handling best practices

## Quick Links

- [Back to Main README](../README.md)
- [Installation Guide](../README.md#installation)
- [Quick Start](../README.md#quick-start)
- [Examples](../examples/)

## Contributing

When adding new documentation:

1. Place architectural docs in the root docs/ directory
2. Tutorial content goes in appropriate subdirectories
3. Keep documents focused and well-structured
4. Update this README when adding new documents