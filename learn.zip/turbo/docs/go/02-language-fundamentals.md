# Language Fundamentals

Welcome to the heart of Go! This chapter reveals the core concepts that make Go tick. By the end, you'll understand Go's type system, control flow, and the building blocks for creating robust applications.

## The Go Type System

Go is statically typed, but it feels lightweight. Let's explore how Go handles data.

### Basic Types: Your Foundation

Go's basic types are refreshingly simple. Let's see them in action:

```go
package main

import "fmt"

func main() {
    // Booleans - only true or false
    var isReady bool = true
    isComplete := false  // Type inferred
    
    // Numbers - integers of various sizes
    var count int = 42           // Platform-dependent size (32 or 64 bits)
    var smallCount int8 = 127    // -128 to 127
    var bigCount int64 = 9223372036854775807
    var positive uint = 42       // Unsigned (no negatives)
    
    // Floating point - for decimals
    var price float32 = 19.99
    var pi float64 = 3.14159265359  // Prefer float64
    
    // Strings - UTF-8 by default
    var message string = "Hello, Turbo!"
    multiline := `This is a
    multiline string
    that preserves formatting`
    
    // Characters - called runes in Go
    var letter rune = 'A'        // Unicode code point (int32)
    var emoji rune = '🚀'
    var asciiChar byte = 'B'     // byte is alias for uint8
}
```

### Zero Values: Go's Safety Net

Unlike some languages, Go doesn't have uninitialized variables. Every variable has a zero value:

```go
func demonstrateZeroValues() {
    var count int          // 0
    var price float64      // 0.0
    var name string        // "" (empty string)
    var isActive bool      // false
    var data []byte        // nil (but safe to use)
    var config *Config     // nil
    
    // This is perfectly safe!
    fmt.Println(len(data)) // Prints: 0
}
```

**Why this matters**: Zero values eliminate entire classes of bugs. You can safely use any variable immediately after declaration.

### Type Conversions: Explicit is Better

Go requires explicit type conversions. This might seem annoying at first, but it prevents subtle bugs:

```go
func typeConversions() {
    var x int = 42
    var y float64 = float64(x)  // Must convert explicitly
    
    // This won't compile:
    // var z float64 = x  // Error: cannot use x as float64
    
    // Converting between strings and bytes
    message := "Hello"
    bytes := []byte(message)     // String to byte slice
    back := string(bytes)        // Byte slice to string
    
    // Number to string (use strconv package)
    import "strconv"
    str := strconv.Itoa(42)      // Int to string
    num, err := strconv.Atoi("42") // String to int
}
```

## Variables and Constants

### Variable Declaration Patterns

Go offers multiple ways to declare variables. Choose based on clarity and context:

```go
// Method 1: var with type
var name string = "Turbo"

// Method 2: var with inferred type
var age = 25  // Go infers int

// Method 3: Short declaration (only inside functions)
count := 10

// Method 4: Multiple variables
var (
    host     = "localhost"
    port     = 8080
    secure   = true
)

// Method 5: Same line multiple
var x, y, z int = 1, 2, 3

// Method 6: Tuple assignment
x, y = y, x  // Swap values!
```

**Best Practice**: Use short declaration (`:=`) inside functions for brevity. Use `var` for package-level variables and when you need a zero value.

### Constants: Immutable Values

Constants are values that never change. Go's constants are special—they're computed at compile time:

```go
const (
    // Numeric constants
    MaxConnections = 100
    Pi            = 3.14159
    
    // String constants
    AppName       = "Turbo"
    Version       = "1.0.0"
    
    // Computed constants
    KB = 1024
    MB = KB * 1024
    GB = MB * 1024
)

// Typed vs untyped constants
const TypedInt int = 42        // Has specific type
const UntypedInt = 42          // Type determined by usage

// iota: Go's enum generator
const (
    Sunday = iota  // 0
    Monday         // 1
    Tuesday        // 2
    Wednesday      // 3
    Thursday       // 4
    Friday         // 5
    Saturday       // 6
)

// Creative iota usage
const (
    _  = iota      // Skip 0
    KB = 1 << (10 * iota)  // 1024
    MB                     // 1048576
    GB                     // 1073741824
)
```

## Control Flow

Go keeps control flow simple: `if`, `for`, and `switch`. That's it. No while loops, no do-while, no foreach. This simplicity is intentional.

### If Statements: Simple and Powerful

```go
func checkStatus(code int) string {
    // Simple if
    if code == 200 {
        return "OK"
    }
    
    // If-else
    if code >= 500 {
        return "Server Error"
    } else if code >= 400 {
        return "Client Error"
    } else {
        return "Unknown"
    }
}

// If with initialization - a Go superpower
func processUser(id int) error {
    // user is scoped to this if block
    if user, err := getUser(id); err != nil {
        return fmt.Errorf("failed to get user: %w", err)
    } else {
        // user is available here
        return processUserData(user)
    }
    // user is NOT available here
}

// Common pattern: early return
func divide(a, b float64) (float64, error) {
    if b == 0 {
        return 0, errors.New("division by zero")
    }
    return a / b, nil
}
```

### For Loops: One Loop to Rule Them All

Go has only `for` loops, but they're incredibly versatile:

```go
func loopExamples() {
    // Classic for loop
    for i := 0; i < 10; i++ {
        fmt.Println(i)
    }
    
    // While-style loop
    count := 0
    for count < 10 {
        fmt.Println(count)
        count++
    }
    
    // Infinite loop
    for {
        // Break or return to exit
        if shouldStop() {
            break
        }
    }
    
    // Range loop - iterate collections
    numbers := []int{1, 2, 3, 4, 5}
    for index, value := range numbers {
        fmt.Printf("numbers[%d] = %d\n", index, value)
    }
    
    // Ignore index with blank identifier
    for _, value := range numbers {
        fmt.Println(value)
    }
    
    // Range over map
    ages := map[string]int{"Alice": 30, "Bob": 25}
    for name, age := range ages {
        fmt.Printf("%s is %d years old\n", name, age)
    }
    
    // Range over string (yields runes)
    for index, char := range "Hello, 世界" {
        fmt.Printf("%d: %c\n", index, char)
    }
}
```

### Switch Statements: Pattern Matching Light

Go's switch is more powerful than in many languages:

```go
func switchExamples(x interface{}) {
    // Basic switch
    day := "Monday"
    switch day {
    case "Monday", "Tuesday", "Wednesday", "Thursday", "Friday":
        fmt.Println("Weekday")
    case "Saturday", "Sunday":
        fmt.Println("Weekend")
    default:
        fmt.Println("Invalid day")
    }
    
    // Switch without expression (replaces if-else chains)
    score := 85
    switch {
    case score >= 90:
        fmt.Println("A")
    case score >= 80:
        fmt.Println("B")
    case score >= 70:
        fmt.Println("C")
    default:
        fmt.Println("F")
    }
    
    // Type switch - powerful for interfaces
    switch v := x.(type) {
    case int:
        fmt.Printf("Integer: %d\n", v)
    case string:
        fmt.Printf("String: %s\n", v)
    case bool:
        fmt.Printf("Boolean: %v\n", v)
    default:
        fmt.Printf("Unknown type: %T\n", v)
    }
    
    // Fallthrough (rare in Go)
    switch num := 2; num {
    case 1:
        fmt.Println("One")
    case 2:
        fmt.Println("Two")
        fallthrough  // Continue to next case
    case 3:
        fmt.Println("Two or Three")
    }
}
```

## Functions: The Workhorses

Functions are first-class citizens in Go. They can be assigned to variables, passed as arguments, and returned from other functions.

### Function Basics

```go
// Simple function
func greet(name string) {
    fmt.Printf("Hello, %s!\n", name)
}

// Function with return value
func add(a, b int) int {
    return a + b
}

// Multiple parameters of same type
func multiply(x, y, z float64) float64 {
    return x * y * z
}

// Multiple return values - a Go specialty
func divide(a, b float64) (float64, error) {
    if b == 0 {
        return 0, errors.New("division by zero")
    }
    return a / b, nil
}

// Named return values
func getCoordinates() (x, y int) {
    x = 10
    y = 20
    return  // Naked return - returns x and y
}

// Variadic functions
func sum(numbers ...int) int {
    total := 0
    for _, n := range numbers {
        total += n
    }
    return total
}

// Usage
result := sum(1, 2, 3, 4, 5)
nums := []int{1, 2, 3}
result = sum(nums...)  // Spread slice with ...
```

### Functions as Values

```go
// Function variables
var operation func(int, int) int

operation = add
fmt.Println(operation(5, 3))  // 8

operation = func(a, b int) int {
    return a * b
}
fmt.Println(operation(5, 3))  // 15

// Functions as parameters
func apply(fn func(int, int) int, a, b int) int {
    return fn(a, b)
}

result := apply(add, 10, 5)

// Functions returning functions
func makeMultiplier(factor int) func(int) int {
    return func(x int) int {
        return x * factor
    }
}

double := makeMultiplier(2)
triple := makeMultiplier(3)

fmt.Println(double(5))   // 10
fmt.Println(triple(5))   // 15
```

### Defer: Cleanup Made Easy

Defer is Go's unique cleanup mechanism. Deferred functions run when the surrounding function returns:

```go
func readFile(filename string) ([]byte, error) {
    file, err := os.Open(filename)
    if err != nil {
        return nil, err
    }
    defer file.Close()  // Guaranteed to run, even if panic occurs
    
    // Read file contents
    return ioutil.ReadAll(file)
}

// Multiple defers execute in LIFO order
func deferOrder() {
    defer fmt.Println("Third")
    defer fmt.Println("Second")
    defer fmt.Println("First")
    // Prints: First, Second, Third
}

// Defer with anonymous functions
func measureTime(name string) func() {
    start := time.Now()
    return func() {
        fmt.Printf("%s took %v\n", name, time.Since(start))
    }
}

func expensiveOperation() {
    defer measureTime("expensiveOperation")()
    // Do work...
    time.Sleep(2 * time.Second)
}
```

## Arrays and Slices

Arrays and slices are fundamental to Go. Arrays have fixed size, while slices are dynamic.

### Arrays: Fixed Size Collections

```go
// Array declaration
var numbers [5]int              // Array of 5 ints, all zero
primes := [5]int{2, 3, 5, 7, 11}  // Initialize with values

// Size is part of the type
var a [5]int
var b [10]int
// a = b  // Error: different types!

// Let Go count elements
langs := [...]string{"Go", "Python", "JavaScript"}

// Multidimensional arrays
var matrix [3][3]int
matrix[0][0] = 1

// Arrays are values (copied when passed)
func modifyArray(arr [5]int) {
    arr[0] = 100  // Doesn't affect original
}
```

### Slices: Dynamic Arrays

Slices are Go's power tool for working with sequences:

```go
// Creating slices
var numbers []int                    // nil slice
numbers = []int{1, 2, 3, 4, 5}      // Literal
numbers = make([]int, 5)             // Length 5, capacity 5
numbers = make([]int, 5, 10)         // Length 5, capacity 10

// Slicing operations
arr := [5]int{1, 2, 3, 4, 5}
slice := arr[1:4]   // [2, 3, 4]
slice = arr[:3]     // [1, 2, 3]
slice = arr[2:]     // [3, 4, 5]
slice = arr[:]      // [1, 2, 3, 4, 5]

// Appending to slices
slice = append(slice, 6)
slice = append(slice, 7, 8, 9)

// Slice internals
fmt.Println(len(slice))  // Current length
fmt.Println(cap(slice))  // Capacity

// Common patterns
// 1. Growing a slice efficiently
result := make([]int, 0, 100)  // Pre-allocate capacity
for i := 0; i < 100; i++ {
    result = append(result, i)
}

// 2. Copying slices
src := []int{1, 2, 3}
dst := make([]int, len(src))
copy(dst, src)

// 3. Filtering
filtered := numbers[:0]  // Reuse backing array
for _, n := range numbers {
    if n%2 == 0 {
        filtered = append(filtered, n)
    }
}

// 4. Stack operations
stack := []int{}
stack = append(stack, 1)        // Push
top := stack[len(stack)-1]      // Peek
stack = stack[:len(stack)-1]    // Pop
```

## Maps: Key-Value Store

Maps are Go's built-in hash tables:

```go
// Creating maps
var ages map[string]int                        // nil map (can't write)
ages = make(map[string]int)                    // Empty map
ages = map[string]int{"Alice": 30, "Bob": 25}  // Literal

// Working with maps
ages["Charlie"] = 35          // Add/update
age := ages["Alice"]          // Get (returns zero value if missing)
delete(ages, "Bob")           // Remove

// Check if key exists
age, exists := ages["David"]
if !exists {
    fmt.Println("David not found")
}

// Iterate maps (order is random!)
for name, age := range ages {
    fmt.Printf("%s: %d\n", name, age)
}

// Maps as sets
set := make(map[string]struct{})
set["apple"] = struct{}{}
if _, exists := set["apple"]; exists {
    fmt.Println("apple is in set")
}

// Nested maps
users := make(map[string]map[string]string)
users["alice"] = map[string]string{
    "email": "alice@example.com",
    "role":  "admin",
}
```

## Structs: Custom Types

Structs group related data together:

```go
// Basic struct
type User struct {
    ID        int
    Username  string
    Email     string
    IsActive  bool
    CreatedAt time.Time
}

// Creating structs
user1 := User{
    ID:       1,
    Username: "alice",
    Email:    "alice@example.com",
    IsActive: true,
}

// Positional initialization (avoid in production)
user2 := User{2, "bob", "bob@example.com", false, time.Now()}

// Zero value struct
var user3 User  // All fields have zero values

// Anonymous structs (great for one-offs)
response := struct {
    Code    int
    Message string
}{
    Code:    200,
    Message: "Success",
}

// Struct embedding (composition)
type Employee struct {
    User        // Embedded struct
    Department  string
    Salary      float64
}

emp := Employee{
    User: User{
        ID:       1,
        Username: "alice",
    },
    Department: "Engineering",
}

// Access embedded fields directly
fmt.Println(emp.Username)  // Works!

// Struct tags (metadata)
type JSONUser struct {
    ID       int    `json:"id"`
    Username string `json:"username"`
    Email    string `json:"email,omitempty"`
    Password string `json:"-"`  // Never included in JSON
}
```

## Methods: Functions with Receivers

Methods are functions attached to types:

```go
// Value receiver
func (u User) FullName() string {
    return u.FirstName + " " + u.LastName
}

// Pointer receiver (can modify)
func (u *User) Activate() {
    u.IsActive = true
    u.UpdatedAt = time.Now()
}

// Method usage
user := User{FirstName: "John", LastName: "Doe"}
fmt.Println(user.FullName())  // "John Doe"

user.Activate()  // Go automatically handles & and *
fmt.Println(user.IsActive)  // true

// Methods on any type (not just structs)
type Counter int

func (c *Counter) Increment() {
    *c++
}

func (c Counter) String() string {
    return fmt.Sprintf("Counter: %d", c)
}
```

### Receiver Type Guidelines

**Use pointer receivers when:**
- The method modifies the receiver
- The receiver is large (avoid copying)
- Consistency (if some methods have pointer receivers)

**Use value receivers when:**
- The method doesn't modify the receiver
- The receiver is small (int, string, etc.)
- You want immutability

## Interfaces: Go's Superpower

Interfaces define behavior. They're satisfied implicitly—no "implements" keyword needed:

```go
// Define interface
type Writer interface {
    Write([]byte) (int, error)
}

// Any type with Write method satisfies Writer
type ConsoleWriter struct{}

func (cw ConsoleWriter) Write(data []byte) (int, error) {
    n, err := fmt.Print(string(data))
    return n, err
}

// Use interface
func saveData(w Writer, data []byte) error {
    _, err := w.Write(data)
    return err
}

// Common interfaces
type Stringer interface {
    String() string
}

type Reader interface {
    Read([]byte) (int, error)
}

type Closer interface {
    Close() error
}

// Interface composition
type ReadCloser interface {
    Reader
    Closer
}

// Empty interface (accepts anything)
func printAnything(v interface{}) {
    fmt.Println(v)
}

// Type assertions
func processValue(v interface{}) {
    // Safe assertion
    if str, ok := v.(string); ok {
        fmt.Printf("String: %s\n", str)
    }
    
    // Type switch (cleaner for multiple types)
    switch value := v.(type) {
    case int:
        fmt.Printf("Integer: %d\n", value)
    case string:
        fmt.Printf("String: %s\n", value)
    case []int:
        fmt.Printf("Int slice: %v\n", value)
    default:
        fmt.Printf("Unknown type: %T\n", value)
    }
}
```

### Interface Best Practices

1. **Keep interfaces small** - The smaller the interface, the more useful
2. **Accept interfaces, return structs** - Maximum flexibility
3. **Interface segregation** - Many small interfaces > one large interface
4. **Design interfaces at point of use** - Not with implementation

## Packages: Code Organization

Packages are how Go organizes and reuses code:

```go
// Package declaration (first line of file)
package mypackage

// Imports
import (
    "fmt"                          // Standard library
    "github.com/user/project/pkg"  // External package
    "myapp/internal/utils"         // Internal package
)

// Package initialization
func init() {
    // Runs when package is imported
    // Can have multiple init functions
    fmt.Println("Package initialized")
}

// Exported (public) - starts with capital
func PublicFunction() {}

type PublicType struct {
    PublicField   int
    privateField  string
}

// Unexported (private) - starts with lowercase
func privateFunction() {}

type privateType struct{}
```

### Import Patterns

```go
import (
    // Standard imports
    "fmt"
    "strings"
    
    // Aliased import
    jsoniter "github.com/json-iterator/go"
    
    // Dot import (avoid in production)
    . "math"
    
    // Blank import (for side effects)
    _ "image/png"
    
    // Grouped imports (gofmt will organize)
    "database/sql"
    _ "github.com/lib/pq"  // PostgreSQL driver
)
```

## Memory Management

Go has automatic memory management with garbage collection, but understanding the basics helps write efficient code:

### Stack vs Heap

```go
// Stack allocation (automatic, fast)
func stackExample() {
    x := 42           // On stack
    y := &x           // y points to stack location
    fmt.Println(*y)   // Still on stack
}  // x and y cleaned up automatically

// Heap allocation (when escaping)
func heapExample() *int {
    x := 42
    return &x  // x escapes to heap
}

// Go decides stack vs heap (escape analysis)
// Use 'go build -gcflags=-m' to see decisions
```

### Pointers

```go
// Pointer basics
x := 42
p := &x        // p points to x
fmt.Println(*p) // Dereference: prints 42
*p = 100       // Modify through pointer
fmt.Println(x)  // Prints 100

// Pointers to structs
user := &User{Name: "Alice"}
user.Name = "Bob"  // Go auto-dereferences

// No pointer arithmetic (Go is safe!)
// p++  // Error: not allowed

// New allocates zeroed memory
ptr := new(int)     // *int pointing to 0
slice := new([]int) // *[]int pointing to nil slice

// Make allocates and initializes
slice2 := make([]int, 10)       // []int with length 10
map1 := make(map[string]int)    // initialized map
chan1 := make(chan int)         // initialized channel
```

## Practice Time!

Let's build a small Turbo component using what we've learned:

```go
package turbo

import (
    "errors"
    "fmt"
    "time"
)

// Task represents a Turbo task
type Task struct {
    ID          string
    Title       string
    Description string
    Status      Status
    Priority    int
    CreatedAt   time.Time
    UpdatedAt   time.Time
}

// Status represents task status
type Status int

const (
    StatusPending Status = iota
    StatusInProgress
    StatusCompleted
    StatusCancelled
)

// String makes Status satisfy Stringer interface
func (s Status) String() string {
    statuses := []string{"Pending", "InProgress", "Completed", "Cancelled"}
    if int(s) < len(statuses) {
        return statuses[s]
    }
    return "Unknown"
}

// TaskManager manages tasks
type TaskManager struct {
    tasks map[string]*Task
}

// NewTaskManager creates a new manager
func NewTaskManager() *TaskManager {
    return &TaskManager{
        tasks: make(map[string]*Task),
    }
}

// AddTask adds a new task
func (tm *TaskManager) AddTask(title, description string, priority int) (*Task, error) {
    if title == "" {
        return nil, errors.New("title cannot be empty")
    }
    
    task := &Task{
        ID:          generateID(),
        Title:       title,
        Description: description,
        Status:      StatusPending,
        Priority:    priority,
        CreatedAt:   time.Now(),
        UpdatedAt:   time.Now(),
    }
    
    tm.tasks[task.ID] = task
    return task, nil
}

// GetTask retrieves a task by ID
func (tm *TaskManager) GetTask(id string) (*Task, error) {
    task, exists := tm.tasks[id]
    if !exists {
        return nil, fmt.Errorf("task %s not found", id)
    }
    return task, nil
}

// UpdateStatus updates task status
func (tm *TaskManager) UpdateStatus(id string, status Status) error {
    task, err := tm.GetTask(id)
    if err != nil {
        return err
    }
    
    task.Status = status
    task.UpdatedAt = time.Now()
    return nil
}

// ListTasks returns all tasks
func (tm *TaskManager) ListTasks() []*Task {
    tasks := make([]*Task, 0, len(tm.tasks))
    for _, task := range tm.tasks {
        tasks = append(tasks, task)
    }
    return tasks
}

// Helper function (would be more complex in real app)
func generateID() string {
    return fmt.Sprintf("task_%d", time.Now().UnixNano())
}
```

## Key Takeaways

You've just learned Go's fundamental building blocks:

1. **Types**: Go's type system is simple but powerful
2. **Variables**: Explicit is better than implicit
3. **Control Flow**: Just if, for, and switch—that's all you need
4. **Functions**: First-class citizens with multiple returns
5. **Data Structures**: Arrays, slices, maps, and structs
6. **Methods**: Functions attached to types
7. **Interfaces**: Define behavior, not implementation
8. **Packages**: Organize code for reuse
9. **Memory**: Automatic management with pointers when needed

## What's Next?

You now have a solid foundation in Go. Ready to write idiomatic Go code? Continue to [Effective Go](03-effective-go.md) to learn the patterns and practices that make Go code shine.

---

*"Don't communicate by sharing memory, share memory by communicating."* - Rob Pike, Go Proverb

Ready to level up? → [Continue to Effective Go](03-effective-go.md)