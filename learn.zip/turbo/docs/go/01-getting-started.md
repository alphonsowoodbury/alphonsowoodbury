# Getting Started with Go

Welcome! This chapter will take you from zero to writing Go code in just a few minutes. By the end, you'll have Go installed, understand its philosophy, and make your first contribution to Turbo.

## Why Go?

Before diving into installation, let's understand why Go exists and why it's perfect for projects like Turbo:

### The Go Story

In 2007, three legendary programmers at Google—Robert Griesemer, Rob Pike, and Ken Thompson—were frustrated. Building large-scale software had become painfully slow. Compile times were measured in hours, not seconds. Dependency management was a nightmare. Concurrency was hard.

They created Go to solve these problems. The result? A language that:
- **Compiles fast** - Full builds in seconds, not minutes
- **Runs fast** - Near C-level performance with garbage collection
- **Scales easily** - Built-in concurrency that actually works
- **Stays simple** - Intentionally small feature set

### The Go Mindset

Go embraces radical simplicity. While other languages add features, Go removes them. This isn't a limitation—it's a superpower. Less complexity means:
- Easier to learn (you can learn Go in a weekend)
- Easier to read (any Go code looks familiar)
- Easier to maintain (fewer ways to break things)
- Easier to collaborate (everyone writes similar code)

**Remember**: In Go, boring is beautiful. Clear beats clever every time.

## Installing Go

Let's get Go running on your machine. The process takes about 5 minutes.

### Step 1: Download Go

Visit [go.dev/dl](https://go.dev/dl/) and download the installer for your operating system.

**Pro tip**: Always install the latest stable version. Go maintains excellent backward compatibility.

### Step 2: Install Go

#### macOS
```bash
# Using Homebrew (recommended)
brew install go

# Or use the downloaded installer
# Just double-click the .pkg file
```

#### Linux
```bash
# Remove any previous Go installation
rm -rf /usr/local/go

# Extract the archive (replace with your version)
sudo tar -C /usr/local -xzf go1.21.5.linux-amd64.tar.gz

# Add Go to your PATH
echo 'export PATH=$PATH:/usr/local/go/bin' >> ~/.bashrc
source ~/.bashrc
```

#### Windows
Run the MSI installer and follow the prompts. Go will be added to your PATH automatically.

### Step 3: Verify Installation

Open a new terminal and run:
```bash
go version
```

You should see something like:
```
go version go1.21.5 darwin/amd64
```

Success! Go is installed. 🎉

## Your Development Environment

### Essential Setup

Go needs to know where to put downloaded packages. Set up your Go workspace:

```bash
# Create your Go workspace
mkdir -p ~/go/{bin,pkg,src}

# Set GOPATH (add to your shell profile)
export GOPATH=$HOME/go
export PATH=$PATH:$GOPATH/bin
```

### Choosing an Editor

Go works with any text editor, but these offer the best experience:

#### VS Code (Recommended for Beginners)
1. Install [VS Code](https://code.visualstudio.com/)
2. Install the [Go extension](https://marketplace.visualstudio.com/items?itemName=golang.Go)
3. Open any `.go` file—VS Code will prompt to install Go tools
4. Click "Install All" when prompted

#### GoLand (Full-Featured IDE)
- Download [GoLand](https://www.jetbrains.com/go/)
- Excellent for large projects
- Free for open source contributors

#### Vim/Neovim (For Terminal Lovers)
- Install [vim-go](https://github.com/fatih/vim-go)
- Run `:GoInstallBinaries` after installation

### Configure Your Editor

Enable these features for the best experience:
- **Format on save** - Automatically formats your code
- **Organize imports** - Adds/removes imports as needed
- **Linting** - Catches common mistakes
- **Code completion** - Speeds up coding

## Your First Go Program

Time to write some Go! Let's create the traditional "Hello, World" program with a Turbo twist.

### Create Your First File

1. Navigate to the Turbo project:
```bash
cd ~/GolandProjects/turbo
```

2. Create a new directory for learning:
```bash
mkdir -p examples/learning
cd examples/learning
```

3. Create `hello.go`:
```go
package main

import "fmt"

func main() {
    fmt.Println("Hello, Turbo! 🚀")
}
```

### Understanding the Code

Let's break down what each line does:

```go
package main
```
Every Go file belongs to a package. The `main` package is special—it defines an executable program.

```go
import "fmt"
```
Imports the `fmt` (format) package from Go's standard library. This gives us printing functions.

```go
func main() {
    // Code here
}
```
The `main` function is your program's entry point. When you run a Go program, this function executes first.

```go
fmt.Println("Hello, Turbo! 🚀")
```
Prints a line to the console. The `ln` suffix adds a newline.

### Run Your Program

```bash
go run hello.go
```

You should see:
```
Hello, Turbo! 🚀
```

Congratulations! You've written and run your first Go program. 🎊

## Go Command Essentials

The `go` command is your Swiss Army knife. Here are the essential commands you'll use daily:

### Running Code
```bash
go run main.go        # Run a single file
go run .             # Run package in current directory
go run ./cmd/app     # Run package in subdirectory
```

### Building Executables
```bash
go build             # Build current package
go build -o myapp    # Build with custom name
go install           # Build and install to $GOPATH/bin
```

### Managing Dependencies
```bash
go mod init          # Initialize a new module
go mod tidy          # Add missing/remove unused dependencies
go get package@version # Add a specific dependency
```

### Testing
```bash
go test              # Run tests in current package
go test ./...        # Run all tests in project
go test -v           # Verbose output
go test -cover       # Show coverage
```

### Getting Help
```bash
go help              # List all commands
go help run          # Get help for specific command
go doc fmt.Println   # View documentation
```

## Understanding Turbo's Structure

Now let's explore how Turbo is organized. Understanding the project structure helps you navigate and contribute effectively.

```
turbo/
├── cmd/                 # Command-line applications
│   └── turbo/          
│       └── main.go     # Entry point
├── internal/           # Private application code
│   ├── api/           # HTTP handlers
│   ├── core/          # Business logic
│   └── storage/       # Data persistence
├── pkg/               # Public libraries
│   └── client/        # Client SDK
├── docs/              # Documentation (you are here!)
├── examples/          # Example code
├── go.mod            # Module definition
└── go.sum            # Dependency checksums
```

### Key Concepts

**cmd/**: Contains `main` packages. Each subdirectory is a separate executable.

**internal/**: Private code that can't be imported by other projects. This is where most application logic lives.

**pkg/**: Public packages that other projects can import and use.

**go.mod**: Defines the module name and dependencies. Think of it as `package.json` for Go.

## Your First Contribution

Let's make your first contribution to Turbo! We'll add your name to the contributors list.

### Step 1: Create a CONTRIBUTORS.md file

First, check if it exists:
```bash
ls CONTRIBUTORS.md
```

If it doesn't exist, let's create it:
```bash
cat > CONTRIBUTORS.md << 'EOF'
# Turbo Contributors

Thank you to everyone who has contributed to Turbo!

## Contributors

<!-- Please add your name in alphabetical order -->

- Your Name (@github-username)
EOF
```

### Step 2: Add Your Name

Edit the file and add your name in alphabetical order.

### Step 3: Verify Your Change

```bash
git status
git diff
```

### Step 4: Commit Your Change

```bash
git add CONTRIBUTORS.md
git commit -m "Add [Your Name] to contributors list"
```

Congratulations! You've made your first contribution. 🎉

## Common Beginner Gotchas

Let's address common stumbling blocks before you hit them:

### 1. Unused Variables
Go doesn't allow unused variables. This code won't compile:
```go
func main() {
    name := "Turbo"  // Error: name declared but not used
}
```

**Fix**: Use the variable or remove it:
```go
func main() {
    name := "Turbo"
    fmt.Println(name)  // Now it's used
}
```

### 2. Unused Imports
Same rule applies to imports:
```go
import (
    "fmt"
    "strings"  // Error if not used
)
```

**Fix**: Your editor should remove unused imports automatically on save.

### 3. Opening Braces
Go enforces brace style. This won't compile:
```go
func main() 
{  // Error: opening brace must be on same line
    fmt.Println("Hello")
}
```

**Fix**: Always put opening braces on the same line:
```go
func main() {
    fmt.Println("Hello")
}
```

### 4. Capitalization Matters
In Go, capitalization determines visibility:
```go
package mypackage

var PublicVar = "visible outside package"
var privateVar = "only visible in package"

func PublicFunc() {}   // Exportable
func privateFunc() {}  // Not exportable
```

### 5. Multiple Return Values
Go functions can return multiple values. Always handle them:
```go
// This function returns a value AND an error
result, err := doSomething()
if err != nil {
    // Handle the error
    return err
}
// Use result
```

## Practice Exercises

Ready to practice? Try these exercises:

### Exercise 1: Personalized Greeting
Modify your hello.go to:
1. Accept a name from command-line arguments
2. Print a personalized greeting
3. Handle the case when no name is provided

<details>
<summary>💡 Hint</summary>

Use `os.Args` to access command-line arguments:
```go
import "os"

if len(os.Args) > 1 {
    name := os.Args[1]
    // Use name
}
```
</details>

### Exercise 2: Turbo Version
Create a program that:
1. Defines a version constant
2. Prints "Turbo version X.Y.Z"
3. Uses proper Go formatting

### Exercise 3: Environment Explorer
Write a program that:
1. Reads the `TURBO_ENV` environment variable
2. Prints different messages for "development", "staging", and "production"
3. Defaults to "development" if not set

## Next Steps

Excellent work! You've:
- ✅ Installed Go and set up your environment
- ✅ Written and run your first Go program
- ✅ Learned essential Go commands
- ✅ Understood Turbo's structure
- ✅ Made your first contribution

Ready to dive deeper? Continue to [Language Fundamentals](02-language-fundamentals.md) to master Go's core concepts.

## Quick Reference

### Essential Commands
```bash
go run main.go       # Run program
go build            # Build executable
go test             # Run tests
go fmt ./...        # Format code
go mod tidy         # Clean up dependencies
```

### Project Navigation
```bash
cd ~/GolandProjects/turbo  # Project root
cd cmd/turbo              # Main application
cd internal/              # Core logic
cd docs/go/              # This documentation
```

### Getting Help
- Run `go help [command]` for command help
- Check `go doc [package]` for package docs
- Visit [go.dev](https://go.dev) for official resources

---

*"The bigger the interface, the weaker the abstraction."* - Rob Pike, Go Proverb

Ready for more? → [Continue to Language Fundamentals](02-language-fundamentals.md)