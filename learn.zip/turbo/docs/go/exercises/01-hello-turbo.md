# Exercise 1: Hello, Turbo!

Welcome to your first Turbo challenge! This exercise will get you writing real Go code for the Turbo project.

## Objective

Create a simple Turbo component that demonstrates basic Go concepts while being genuinely useful for the project.

## Your Mission

Build a `HealthChecker` component that:
1. Checks if various Turbo services are running
2. Reports their status
3. Uses proper error handling
4. Follows Go idioms

## Step 1: Create the Structure

Create a new file: `internal/health/checker.go`

Start with this skeleton:

```go
package health

import (
    "context"
    "time"
)

// Status represents the health status of a service
type Status string

const (
    StatusHealthy   Status = "healthy"
    StatusUnhealthy Status = "unhealthy"
    StatusUnknown   Status = "unknown"
)

// CheckResult contains the result of a health check
type CheckResult struct {
    Service   string
    Status    Status
    Message   string
    Duration  time.Duration
    Timestamp time.Time
}

// Checker performs health checks on services
type Checker struct {
    // TODO: Add fields
}

// NewChecker creates a new health checker
func NewChecker() *Checker {
    // TODO: Implement
}

// Check performs a health check on all registered services
func (c *Checker) Check(ctx context.Context) ([]CheckResult, error) {
    // TODO: Implement
}
```

## Step 2: Implement Service Registration

Add the ability to register services for health checking:

```go
// Service represents a service that can be health checked
type Service interface {
    Name() string
    Check(ctx context.Context) error
}

// Register adds a service to be checked
func (c *Checker) Register(service Service) {
    // TODO: Implement
}
```

## Step 3: Create a Test Service

Implement a simple test service:

```go
// PingService checks if a URL is reachable
type PingService struct {
    name string
    url  string
}

func NewPingService(name, url string) *PingService {
    // TODO: Implement
}

func (p *PingService) Name() string {
    // TODO: Implement
}

func (p *PingService) Check(ctx context.Context) error {
    // TODO: Implement
    // Hint: Use http.Get with context
}
```

## Step 4: Add Concurrency

Make the health checks run concurrently:

1. All services should be checked in parallel
2. Use a timeout for each check (e.g., 5 seconds)
3. Collect all results, even if some fail

## Step 5: Write Tests

Create `internal/health/checker_test.go`:

```go
package health

import (
    "context"
    "testing"
    "time"
)

func TestChecker_Check(t *testing.T) {
    // TODO: Test successful check
    // TODO: Test timeout
    // TODO: Test multiple services
    // TODO: Test error handling
}
```

## Bonus Challenges

1. **Add Retry Logic**: If a service fails, retry up to 3 times with exponential backoff
2. **Add Metrics**: Track how long each service typically takes to respond
3. **Add Caching**: Cache results for 30 seconds to avoid overwhelming services
4. **Add HTTP Handler**: Create an HTTP endpoint that returns health status as JSON

## Hints

<details>
<summary>Hint 1: Concurrent Checking</summary>

Use goroutines and channels:
```go
results := make(chan CheckResult, len(c.services))
for _, service := range c.services {
    go func(svc Service) {
        // Perform check and send result to channel
    }(service)
}
```
</details>

<details>
<summary>Hint 2: Context with Timeout</summary>

```go
checkCtx, cancel := context.WithTimeout(ctx, 5*time.Second)
defer cancel()
err := service.Check(checkCtx)
```
</details>

<details>
<summary>Hint 3: HTTP Check Implementation</summary>

```go
req, err := http.NewRequestWithContext(ctx, "GET", p.url, nil)
if err != nil {
    return err
}
resp, err := http.DefaultClient.Do(req)
if err != nil {
    return err
}
defer resp.Body.Close()

if resp.StatusCode != http.StatusOK {
    return fmt.Errorf("unhealthy: status %d", resp.StatusCode)
}
```
</details>

## Expected Output

When you run your health checker, you should see something like:

```
Service: API Gateway
Status: healthy
Duration: 45ms

Service: Database
Status: healthy  
Duration: 12ms

Service: Cache
Status: unhealthy
Message: connection refused
Duration: 5s (timeout)
```

## Submission

Once complete:
1. Ensure all tests pass
2. Run `go fmt` on your code
3. Add a simple example in `examples/health/main.go`
4. Create a pull request with your implementation

## Reflection Questions

After completing this exercise, consider:

1. How did Go's error handling help you handle failures gracefully?
2. What made concurrent checking easier or harder than expected?
3. How would you extend this for production use?
4. What Go idioms did you apply?

## Next Steps

Congratulations on building your first Turbo component! You've practiced:
- Struct and interface design
- Concurrent programming
- Error handling
- Testing
- Following Go conventions

Ready for the next challenge? → [Exercise 2: Error Detective](02-error-detective.md)

---

*Remember: In Go, working code is better than perfect code. Get it working, then make it better!*