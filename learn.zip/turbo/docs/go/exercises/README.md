# Go Exercises for Turbo

Welcome to the hands-on exercises! These challenges are designed to reinforce your Go learning while contributing real value to the Turbo project.

## Exercise Philosophy

Each exercise follows these principles:
- **Real-world relevance**: Every exercise builds something useful for Turbo
- **Progressive difficulty**: Start simple, build complexity
- **Test-driven**: Write tests to verify your solution
- **Idiomatic Go**: Practice writing Go the way Gophers write Go

## Exercise List

### Foundation Exercises (Start Here)

1. **[Hello, Turbo!](01-hello-turbo.md)** - Build a health checker component
   - Topics: Structs, interfaces, concurrency basics
   - Difficulty: ⭐⭐
   - Time: 45 minutes

2. **[Error Detective](02-error-detective.md)** - Debug and improve error handling
   - Topics: Error wrapping, custom errors, debugging
   - Difficulty: ⭐⭐⭐
   - Time: 60 minutes

3. **[Concurrent Worker](03-concurrent-worker.md)** - Build a job processing system
   - Topics: Goroutines, channels, worker pools
   - Difficulty: ⭐⭐⭐⭐
   - Time: 90 minutes

### Intermediate Exercises

4. **[Test Warrior](04-test-warrior.md)** - Achieve 100% test coverage
   - Topics: Table-driven tests, mocking, benchmarks
   - Difficulty: ⭐⭐⭐
   - Time: 60 minutes

5. **[Performance Hunter](05-performance-hunter.md)** - Optimize slow code
   - Topics: Profiling, benchmarking, optimization
   - Difficulty: ⭐⭐⭐⭐
   - Time: 90 minutes

### Advanced Exercises

6. **[API Builder](06-api-builder.md)** - Create a RESTful API
   - Topics: HTTP handlers, middleware, JSON
   - Difficulty: ⭐⭐⭐⭐
   - Time: 2 hours

7. **[State Machine](07-state-machine.md)** - Implement a job state machine
   - Topics: Design patterns, interfaces, testing
   - Difficulty: ⭐⭐⭐⭐⭐
   - Time: 2 hours

8. **[Plugin System](08-plugin-system.md)** - Build an extensible plugin system
   - Topics: Interfaces, dependency injection, design
   - Difficulty: ⭐⭐⭐⭐⭐
   - Time: 3 hours

## How to Use These Exercises

### For Each Exercise:

1. **Read the brief** - Understand what you're building and why
2. **Try it yourself** - Attempt the solution before looking at hints
3. **Use the hints** - They're there when you get stuck
4. **Write tests** - Verify your solution works
5. **Review the solution** - Compare with the reference implementation
6. **Reflect** - Consider what you learned and how to apply it

### Getting Help

- Each exercise has progressive hints
- Reference solutions are available (but try first!)
- Ask in #turbo-dev if you're stuck
- Pair with another learner for difficult exercises

### Tracking Progress

Mark your progress here:

```markdown
- [ ] Exercise 1: Hello, Turbo!
- [ ] Exercise 2: Error Detective
- [ ] Exercise 3: Concurrent Worker
- [ ] Exercise 4: Test Warrior
- [ ] Exercise 5: Performance Hunter
- [ ] Exercise 6: API Builder
- [ ] Exercise 7: State Machine
- [ ] Exercise 8: Plugin System
```

## Contributing New Exercises

Have an idea for a new exercise? We'd love your contribution!

### Good Exercise Criteria:
- Solves a real Turbo need
- Teaches specific Go concepts
- Has clear success criteria
- Includes test cases
- Provides learning value

### Exercise Template:

```markdown
# Exercise N: Title

## Objective
What will the learner build and why?

## Learning Goals
- Concept 1
- Concept 2
- Concept 3

## Requirements
1. Specific requirement
2. Another requirement
3. Performance requirement

## Starter Code
```go
// Provide skeleton code
```

## Hints
<details>
<summary>Hint 1</summary>
Progressive hint content
</details>

## Expected Output
Show what success looks like

## Bonus Challenges
1. Additional challenge
2. Another challenge

## Reflection Questions
1. What did you learn?
2. How would you improve it?
```

## Ready to Start?

Pick an exercise that matches your current skill level and dive in! Remember:

> "The only way to learn a new programming language is by writing programs in it." - Dennis Ritchie

Start with → [Exercise 1: Hello, Turbo!](01-hello-turbo.md)

---

*Happy coding! May your builds be fast and your tests be green.* 🚀