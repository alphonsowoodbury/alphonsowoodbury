# Effective Go: Writing Idiomatic Code

Welcome to the art of Go! This chapter transforms you from someone who writes Go to someone who writes *Go*. You'll learn the idioms, patterns, and philosophies that make Go code elegant, maintainable, and distinctly Go-like.

## The Go Philosophy

Before diving into patterns, let's understand the principles that guide Go development:

### Simplicity Over Cleverness

```go
// ❌ Clever but confusing
func obfuscated(x int) int {
    return x&-x == x && x != 0 && x&(x-1) == 0
}

// ✅ Clear and obvious
func isPowerOfTwo(x int) bool {
    if x <= 0 {
        return false
    }
    return x&(x-1) == 0
}
```

### Explicit Over Implicit

```go
// ❌ Implicit behavior
func process(data string) {
    // Silently ignores errors
    result, _ := strconv.Atoi(data)
    fmt.Println(result)
}

// ✅ Explicit error handling
func process(data string) error {
    result, err := strconv.Atoi(data)
    if err != nil {
        return fmt.Errorf("invalid number %q: %w", data, err)
    }
    fmt.Println(result)
    return nil
}
```

### Composition Over Inheritance

```go
// ❌ Trying to force inheritance
type Animal interface {
    Speak() string
    Move() string
    Eat() string
}

// ✅ Small, composable interfaces
type Speaker interface {
    Speak() string
}

type Mover interface {
    Move() string
}

// Compose behaviors
type Dog struct {
    name string
}

func (d Dog) Speak() string { return "Woof!" }
func (d Dog) Move() string  { return "Runs" }
```

## Naming: The Foundation of Clarity

Good names are crucial in Go. They're your primary documentation.

### Package Names

```go
// ❌ Poor package names
package util          // Too generic
package common        // Meaningless
package helpers       // Vague
package turboUtils    // Stutters, mixed case

// ✅ Good package names
package http          // Clear purpose
package json          // Single responsibility
package turbo         // Project name is fine
package storage       // Descriptive
```

### Variable Names

Go favors short names in small scopes, descriptive names in large scopes:

```go
// ✅ Short names in small scopes
for i := 0; i < 10; i++ {
    fmt.Println(i)
}

// ✅ Single letter for common types
var s string  // string
var i int     // integer
var b []byte  // byte slice
var r io.Reader  // reader

// ✅ Descriptive names for larger scopes
type UserService struct {
    database     *sql.DB
    cacheTimeout time.Duration
    logger       *log.Logger
}

// ❌ Too verbose for small scope
for index := 0; index < 10; index++ {
    fmt.Println(index)
}

// ❌ Too short for package level
var d *sql.DB  // What's d?
```

### Function Names

```go
// ✅ Good function names
func (u *User) Save() error              // Method: verb
func NewUser(name string) *User          // Constructor: New + Type
func ParseTime(s string) (time.Time, error)  // Action + Object
func (c *Cache) IsExpired() bool         // Predicate: Is/Has/Can

// ❌ Poor function names
func (u *User) UserSave() error          // Stutters
func MakeUser(name string) *User         // Use New, not Make
func TimeParser(s string) (time.Time, error)  // Noun, not verb
func (c *Cache) CheckExpired() bool      // Vague
```

### Interface Names

```go
// ✅ Single method interfaces often end in -er
type Reader interface {
    Read([]byte) (int, error)
}

type Stringer interface {
    String() string
}

// ✅ Descriptive names for larger interfaces
type FileSystem interface {
    Open(name string) (File, error)
    Stat(name string) (FileInfo, error)
}

// ❌ Poor interface names
type ReaderInterface interface{}  // Don't add Interface suffix
type IReader interface{}          // Don't use I prefix
```

## Error Handling: The Go Way

Error handling is where Go's philosophy shines. Errors are values, not exceptions.

### Creating Meaningful Errors

```go
// ✅ Wrap errors with context
func loadConfig(path string) (*Config, error) {
    data, err := os.ReadFile(path)
    if err != nil {
        return nil, fmt.Errorf("reading config file %s: %w", path, err)
    }
    
    var cfg Config
    if err := json.Unmarshal(data, &cfg); err != nil {
        return nil, fmt.Errorf("parsing config file %s: %w", path, err)
    }
    
    return &cfg, nil
}

// ✅ Custom error types for specific handling
type ValidationError struct {
    Field string
    Value interface{}
    Msg   string
}

func (e ValidationError) Error() string {
    return fmt.Sprintf("validation failed for %s: %s (got %v)", 
        e.Field, e.Msg, e.Value)
}

// ✅ Sentinel errors for comparison
var (
    ErrNotFound      = errors.New("item not found")
    ErrUnauthorized  = errors.New("unauthorized access")
    ErrDuplicateKey  = errors.New("duplicate key")
)

// Usage
if errors.Is(err, ErrNotFound) {
    // Handle not found case
}
```

### Error Handling Patterns

```go
// ✅ Early return pattern
func processUser(id string) error {
    user, err := fetchUser(id)
    if err != nil {
        return fmt.Errorf("fetch user %s: %w", id, err)
    }
    
    if err := validateUser(user); err != nil {
        return fmt.Errorf("validate user %s: %w", id, err)
    }
    
    if err := saveUser(user); err != nil {
        return fmt.Errorf("save user %s: %w", id, err)
    }
    
    return nil
}

// ✅ Error grouping for cleanup
func processFiles(paths []string) error {
    var errs []error
    
    for _, path := range paths {
        if err := processFile(path); err != nil {
            errs = append(errs, fmt.Errorf("file %s: %w", path, err))
        }
    }
    
    if len(errs) > 0 {
        return fmt.Errorf("processed with %d errors: %v", len(errs), errs)
    }
    
    return nil
}

// ✅ Retry with backoff
func fetchWithRetry(url string, maxRetries int) (*Response, error) {
    var lastErr error
    backoff := 100 * time.Millisecond
    
    for i := 0; i < maxRetries; i++ {
        resp, err := fetch(url)
        if err == nil {
            return resp, nil
        }
        
        lastErr = err
        if !isRetryable(err) {
            return nil, err
        }
        
        time.Sleep(backoff)
        backoff *= 2
    }
    
    return nil, fmt.Errorf("failed after %d retries: %w", maxRetries, lastErr)
}
```

## Zero Values: Your Friend

Go's zero values are useful defaults. Design your types to be useful at their zero value:

```go
// ✅ Useful zero values
type Buffer struct {
    buf []byte
}

// Zero value is ready to use
var b Buffer
b.Write([]byte("hello"))  // Works!

// ✅ Sync types work at zero value
var mu sync.Mutex
mu.Lock()  // No initialization needed

var wg sync.WaitGroup
wg.Add(1)  // Ready to go

// ✅ Design APIs around zero values
type Config struct {
    Port    int           // 0 means default port
    Timeout time.Duration // 0 means no timeout
    Retries int           // 0 means no retries
}

func NewServer(cfg Config) *Server {
    // Apply defaults for zero values
    if cfg.Port == 0 {
        cfg.Port = 8080
    }
    // ...
}
```

## Interfaces: Small is Beautiful

Go interfaces should be small and focused:

```go
// ✅ Small, focused interfaces
type Reader interface {
    Read([]byte) (int, error)
}

type Writer interface {
    Write([]byte) (int, error)
}

type Closer interface {
    Close() error
}

// ✅ Compose when needed
type ReadWriter interface {
    Reader
    Writer
}

type ReadWriteCloser interface {
    Reader
    Writer
    Closer
}

// ✅ Define interfaces where used, not where implemented
package storage

// Define what YOU need, not what implementations provide
type Store interface {
    Get(key string) ([]byte, error)
    Put(key string, value []byte) error
}

// ❌ Avoid large interfaces
type Database interface {
    Connect() error
    Disconnect() error
    Query(string, ...interface{}) (*Rows, error)
    Exec(string, ...interface{}) (Result, error)
    Begin() (*Tx, error)
    Prepare(string) (*Stmt, error)
    // ... 20 more methods
}
```

### Interface Satisfaction

```go
// ✅ Verify interface satisfaction at compile time
var _ io.Writer = (*MyWriter)(nil)
var _ json.Marshaler = (*Config)(nil)

// This pattern catches issues early
type MyWriter struct{}

var _ io.Writer = (*MyWriter)(nil)  // Compile error if not satisfied

func (w *MyWriter) Write(p []byte) (n int, err error) {
    // Implementation
}
```

## Concurrency Patterns

Go's concurrency is built on CSP (Communicating Sequential Processes). Here are the essential patterns:

### Don't Communicate by Sharing Memory

```go
// ❌ Sharing memory (race condition!)
var counter int

func increment() {
    counter++  // DATA RACE!
}

// ✅ Share memory by communicating
type Counter struct {
    ch chan int
}

func NewCounter() *Counter {
    c := &Counter{ch: make(chan int)}
    go c.run()
    return c
}

func (c *Counter) run() {
    var count int
    for delta := range c.ch {
        count += delta
    }
}

func (c *Counter) Increment() {
    c.ch <- 1
}
```

### Channel Patterns

```go
// ✅ Fan-out: Distribute work
func fanOut(in <-chan int, workers int) []<-chan int {
    outs := make([]<-chan int, workers)
    
    for i := 0; i < workers; i++ {
        out := make(chan int)
        outs[i] = out
        
        go func() {
            for val := range in {
                out <- process(val)
            }
            close(out)
        }()
    }
    
    return outs
}

// ✅ Fan-in: Merge results
func fanIn(ins ...<-chan int) <-chan int {
    out := make(chan int)
    var wg sync.WaitGroup
    
    wg.Add(len(ins))
    for _, in := range ins {
        go func(ch <-chan int) {
            for val := range ch {
                out <- val
            }
            wg.Done()
        }(in)
    }
    
    go func() {
        wg.Wait()
        close(out)
    }()
    
    return out
}

// ✅ Pipeline pattern
func pipeline() {
    numbers := generate(1, 100)
    squares := square(numbers)
    filtered := filter(squares, isEven)
    
    for result := range filtered {
        fmt.Println(result)
    }
}
```

### Context for Cancellation

```go
// ✅ Propagate cancellation
func fetchAll(ctx context.Context, urls []string) ([]string, error) {
    results := make([]string, len(urls))
    errors := make([]error, len(urls))
    
    var wg sync.WaitGroup
    for i, url := range urls {
        wg.Add(1)
        go func(i int, url string) {
            defer wg.Done()
            results[i], errors[i] = fetchWithContext(ctx, url)
        }(i, url)
    }
    
    wg.Wait()
    
    // Check for errors
    for _, err := range errors {
        if err != nil {
            return nil, err
        }
    }
    
    return results, nil
}

func fetchWithContext(ctx context.Context, url string) (string, error) {
    req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
    if err != nil {
        return "", err
    }
    
    resp, err := http.DefaultClient.Do(req)
    if err != nil {
        return "", err
    }
    defer resp.Body.Close()
    
    // Read response...
}
```

## Package Design

Good package design is crucial for maintainable code:

### Package Structure

```go
// ✅ Good package structure
turbo/
├── cmd/
│   └── turbo/
│       └── main.go          // package main
├── internal/
│   ├── auth/
│   │   ├── auth.go          // package auth
│   │   ├── token.go
│   │   └── auth_test.go
│   └── storage/
│       ├── storage.go       // package storage
│       ├── memory.go
│       └── disk.go
└── pkg/
    └── client/
        ├── client.go        // package client
        └── client_test.go
```

### Package Guidelines

```go
// ✅ Package comment describes purpose
// Package auth provides authentication and authorization functionality
// for the Turbo application. It supports multiple authentication methods
// including JWT tokens and API keys.
package auth

// ✅ Related functionality in same package
package http

type Server struct{}
type Handler func(ResponseWriter, *Request)
type ResponseWriter interface{}
type Request struct{}

// ❌ Avoid package sprawl
package models      // Too generic
package utils       // Dumping ground
package helpers     // Meaningless
package common      // What's common?
```

## Code Organization

### Organize by Functionality

```go
// ✅ Group related declarations
package user

// Core types first
type User struct {
    ID        string
    Email     string
    Name      string
    CreatedAt time.Time
}

type Role int

const (
    RoleUser Role = iota
    RoleAdmin
    RoleSuperAdmin
)

// Constructors
func NewUser(email, name string) *User {
    return &User{
        ID:        generateID(),
        Email:     email,
        Name:      name,
        CreatedAt: time.Now(),
    }
}

// Methods grouped by receiver
func (u *User) Validate() error {
    if u.Email == "" {
        return errors.New("email required")
    }
    return nil
}

func (u *User) IsAdmin() bool {
    return u.Role >= RoleAdmin
}

// Related functions
func ValidateEmail(email string) error {
    // Validation logic
}
```

### Reduce Coupling

```go
// ✅ Accept interfaces, return structs
func ProcessData(r io.Reader) (*Result, error) {
    // Can work with files, network, buffers, etc.
}

// ✅ Inject dependencies
type Service struct {
    repo Repository  // Interface
    log  Logger      // Interface
}

func NewService(repo Repository, log Logger) *Service {
    return &Service{
        repo: repo,
        log:  log,
    }
}

// ❌ Avoid global state
var (
    db     *sql.DB      // Global database
    config *Config      // Global config
)
```

## Performance Considerations

Write clear code first, optimize later:

### Efficient String Building

```go
// ❌ Inefficient string concatenation
func badJoin(parts []string) string {
    result := ""
    for _, part := range parts {
        result += part  // Creates new string each time
    }
    return result
}

// ✅ Use strings.Builder
func goodJoin(parts []string) string {
    var sb strings.Builder
    for _, part := range parts {
        sb.WriteString(part)
    }
    return sb.String()
}

// ✅ Even better: use standard library
func bestJoin(parts []string) string {
    return strings.Join(parts, "")
}
```

### Slice Preallocation

```go
// ❌ Growing slice incrementally
func collectItems() []Item {
    var items []Item
    for i := 0; i < 1000; i++ {
        items = append(items, fetchItem(i))
    }
    return items
}

// ✅ Preallocate when size is known
func collectItems() []Item {
    items := make([]Item, 0, 1000)
    for i := 0; i < 1000; i++ {
        items = append(items, fetchItem(i))
    }
    return items
}
```

## Documentation

Good documentation is part of idiomatic Go:

```go
// ✅ Package documentation
// Package turbo provides a high-performance task processing system.
// It supports concurrent execution, job queuing, and real-time monitoring.
//
// Basic usage:
//
//	engine := turbo.New()
//	engine.Start()
//	defer engine.Stop()
//
//	job := turbo.Job{
//	    Type: "process",
//	    Data: data,
//	}
//	engine.Submit(job)
package turbo

// ✅ Exported type documentation
// User represents a system user with authentication credentials
// and associated metadata.
type User struct {
    // ID is the unique identifier for the user
    ID string
    
    // Email is the user's email address and primary identifier
    Email string
    
    // unexported fields don't need comments
    passwordHash []byte
}

// ✅ Function documentation
// HashPassword generates a bcrypt hash of the provided password.
// It uses a cost factor of 12 for adequate security.
// The returned hash is safe to store in the database.
func HashPassword(password string) ([]byte, error) {
    return bcrypt.GenerateFromPassword([]byte(password), 12)
}
```

## Testing Considerations

Write testable code from the start:

```go
// ✅ Testable design
type TimeProvider interface {
    Now() time.Time
}

type Cache struct {
    data map[string]cacheEntry
    time TimeProvider  // Inject time dependency
}

// In tests, use a mock time
type mockTime struct {
    current time.Time
}

func (m *mockTime) Now() time.Time {
    return m.current
}

// ✅ Export test helpers in test files
// export_test.go
package mypackage

// Export internal functions for testing
var ProcessInternal = processInternal
```

## Common Antipatterns to Avoid

### The Mega Interface

```go
// ❌ Don't create huge interfaces
type UserService interface {
    Create(user User) error
    Update(id string, user User) error
    Delete(id string) error
    Get(id string) (User, error)
    List(filter Filter) ([]User, error)
    Authenticate(username, password string) (Token, error)
    Authorize(token Token, resource string) error
    // ... 20 more methods
}

// ✅ Split into focused interfaces
type UserRepository interface {
    Create(user User) error
    Update(id string, user User) error
    Delete(id string) error
    Get(id string) (User, error)
}

type Authenticator interface {
    Authenticate(username, password string) (Token, error)
}
```

### Init() Madness

```go
// ❌ Avoid complex init functions
func init() {
    // Database connection in init - bad!
    db, err := sql.Open("postgres", os.Getenv("DB_URL"))
    if err != nil {
        panic(err)
    }
    globalDB = db
}

// ✅ Explicit initialization
func Initialize(dbURL string) (*DB, error) {
    return sql.Open("postgres", dbURL)
}
```

### Empty Interface Overuse

```go
// ❌ Avoid interface{} when possible
func process(data interface{}) {
    // Requires type assertions everywhere
}

// ✅ Use specific types or interfaces
func process(data Processor) {
    data.Process()
}
```

## Real-World Example: Building a Turbo Component

Let's apply these principles to build an idiomatic Turbo component:

```go
// Package worker provides concurrent job processing for Turbo.
package worker

import (
    "context"
    "fmt"
    "sync"
    "time"
)

// Job represents a unit of work to be processed.
type Job interface {
    ID() string
    Execute(ctx context.Context) error
}

// Result contains the outcome of job execution.
type Result struct {
    JobID    string
    Duration time.Duration
    Err      error
}

// Pool manages a group of workers for concurrent job processing.
type Pool struct {
    workers int
    jobs    chan Job
    results chan Result
    wg      sync.WaitGroup
    
    // Graceful shutdown
    ctx    context.Context
    cancel context.CancelFunc
}

// New creates a new worker pool with the specified number of workers.
func New(workers int) *Pool {
    ctx, cancel := context.WithCancel(context.Background())
    
    return &Pool{
        workers: workers,
        jobs:    make(chan Job),
        results: make(chan Result),
        ctx:     ctx,
        cancel:  cancel,
    }
}

// Start begins processing jobs with the configured workers.
func (p *Pool) Start() {
    for i := 0; i < p.workers; i++ {
        p.wg.Add(1)
        go p.worker(i)
    }
}

// Submit adds a job to the processing queue.
// It returns immediately and doesn't wait for job completion.
func (p *Pool) Submit(job Job) error {
    select {
    case p.jobs <- job:
        return nil
    case <-p.ctx.Done():
        return fmt.Errorf("pool is shutting down")
    }
}

// Results returns a channel for receiving job results.
// The channel is closed when the pool is shut down.
func (p *Pool) Results() <-chan Result {
    return p.results
}

// Shutdown gracefully stops all workers and waits for completion.
func (p *Pool) Shutdown() {
    close(p.jobs)    // No more jobs
    p.wg.Wait()      // Wait for workers
    p.cancel()       // Cancel context
    close(p.results) // Close results
}

func (p *Pool) worker(id int) {
    defer p.wg.Done()
    
    for job := range p.jobs {
        start := time.Now()
        err := job.Execute(p.ctx)
        
        result := Result{
            JobID:    job.ID(),
            Duration: time.Since(start),
            Err:      err,
        }
        
        select {
        case p.results <- result:
        case <-p.ctx.Done():
            return
        }
    }
}
```

## Summary: The Go Way

You've learned to write Go that feels natural and idiomatic. Remember:

1. **Clarity over cleverness** - If it's not obvious, it's probably wrong
2. **Small interfaces** - The bigger the interface, the weaker the abstraction
3. **Errors are values** - Handle them explicitly
4. **Zero values are useful** - Design types to work without initialization
5. **Composition over inheritance** - Embed types and satisfy interfaces
6. **Concurrency through communication** - Don't share memory
7. **Document the why, not the what** - Code shows what, docs explain why

## What's Next?

You're writing idiomatic Go! Ready to master error handling? Continue to [Error Handling](04-error-handling.md) for deep insights into Go's approach to errors.

---

*"Gofmt's style is no one's favorite, yet gofmt is everyone's favorite."* - Rob Pike, Go Proverb

Ready to master errors? → [Continue to Error Handling](04-error-handling.md)