# Error Handling: The Go Way

Error handling is where Go's philosophy truly shines. Instead of exceptions that can appear from anywhere, Go treats errors as values that flow through your program naturally. This chapter will transform how you think about errors.

## The Philosophy of Errors

### Errors Are Values, Not Exceptions

In Go, errors are just values that implement the `error` interface:

```go
type error interface {
    Error() string
}
```

That's it. This simplicity is powerful.

### Why No Exceptions?

Go's designers made a deliberate choice:

```go
// ❌ Exception-based (hidden control flow)
try {
    user = fetchUser(id)
    user.process()
    user.save()
} catch (NetworkException e) {
    // Where did this come from?
} catch (DatabaseException e) {
    // Was it from save()?
}

// ✅ Go's explicit errors (clear control flow)
user, err := fetchUser(id)
if err != nil {
    return fmt.Errorf("fetch user: %w", err)
}

if err := user.process(); err != nil {
    return fmt.Errorf("process user: %w", err)
}

if err := user.save(); err != nil {
    return fmt.Errorf("save user: %w", err)
}
```

The Go way makes error handling:
- **Visible**: You can't ignore errors accidentally
- **Local**: Errors are handled where they occur
- **Composable**: Errors flow through your program like any other value

## Creating Errors

### Simple Errors

```go
// Using errors.New for constant errors
var ErrNotFound = errors.New("not found")
var ErrInvalidInput = errors.New("invalid input")

// Using fmt.Errorf for dynamic errors
func validateAge(age int) error {
    if age < 0 {
        return fmt.Errorf("age cannot be negative: %d", age)
    }
    if age > 150 {
        return fmt.Errorf("age too high: %d", age)
    }
    return nil
}
```

### Custom Error Types

When you need more than a string, create custom error types:

```go
// Simple custom error
type ValidationError struct {
    Field string
    Value interface{}
}

func (e ValidationError) Error() string {
    return fmt.Sprintf("validation failed for field %s: invalid value %v", 
        e.Field, e.Value)
}

// Rich error with multiple fields
type APIError struct {
    Code       string    `json:"code"`
    Message    string    `json:"message"`
    StatusCode int       `json:"-"`
    Details    map[string]interface{} `json:"details,omitempty"`
    Timestamp  time.Time `json:"timestamp"`
}

func (e APIError) Error() string {
    return fmt.Sprintf("[%s] %s", e.Code, e.Message)
}

// Error with behavior
type RetryableError struct {
    Err        error
    RetryAfter time.Duration
}

func (e RetryableError) Error() string {
    return fmt.Sprintf("retryable error (retry after %v): %v", 
        e.RetryAfter, e.Err)
}

func (e RetryableError) Unwrap() error {
    return e.Err
}
```

### Error Wrapping (Go 1.13+)

Error wrapping adds context while preserving the original error:

```go
func processOrder(orderID string) error {
    order, err := fetchOrder(orderID)
    if err != nil {
        // Wrap with context
        return fmt.Errorf("processing order %s: %w", orderID, err)
    }
    
    if err := validateOrder(order); err != nil {
        // More specific context
        return fmt.Errorf("invalid order %s: %w", orderID, err)
    }
    
    if err := chargePayment(order); err != nil {
        // Business context
        return fmt.Errorf("payment failed for order %s ($%.2f): %w", 
            orderID, order.Total, err)
    }
    
    return nil
}
```

The `%w` verb wraps the error, creating an error chain.

## Checking and Handling Errors

### The Standard Pattern

```go
func doSomething() error {
    result, err := operation()
    if err != nil {
        // Handle error immediately
        return fmt.Errorf("operation failed: %w", err)
    }
    
    // Continue with result
    return processResult(result)
}
```

### Checking Wrapped Errors

```go
// Define sentinel errors
var (
    ErrNotFound      = errors.New("not found")
    ErrUnauthorized  = errors.New("unauthorized")
    ErrRateLimit     = errors.New("rate limit exceeded")
)

func handleError(err error) {
    // Check if error chain contains specific error
    if errors.Is(err, ErrNotFound) {
        // Handle not found case
        respondWithStatus(404)
        return
    }
    
    if errors.Is(err, ErrUnauthorized) {
        // Handle auth failure
        redirectToLogin()
        return
    }
    
    // Check for error types
    var apiErr *APIError
    if errors.As(err, &apiErr) {
        // Handle API error specifically
        respondWithJSON(apiErr.StatusCode, apiErr)
        return
    }
    
    // Default error handling
    respondWithStatus(500)
}
```

### Multiple Error Returns

Sometimes you need to handle multiple operations that might fail:

```go
// Parallel operations with error collection
func fetchUserData(userID string) (*UserData, error) {
    var (
        user    *User
        profile *Profile
        prefs   *Preferences
        
        userErr, profileErr, prefsErr error
        wg sync.WaitGroup
    )
    
    wg.Add(3)
    
    go func() {
        defer wg.Done()
        user, userErr = fetchUser(userID)
    }()
    
    go func() {
        defer wg.Done()
        profile, profileErr = fetchProfile(userID)
    }()
    
    go func() {
        defer wg.Done()
        prefs, prefsErr = fetchPreferences(userID)
    }()
    
    wg.Wait()
    
    // Combine errors
    if err := firstError(userErr, profileErr, prefsErr); err != nil {
        return nil, fmt.Errorf("fetching user data: %w", err)
    }
    
    return &UserData{
        User:        user,
        Profile:     profile,
        Preferences: prefs,
    }, nil
}

func firstError(errs ...error) error {
    for _, err := range errs {
        if err != nil {
            return err
        }
    }
    return nil
}
```

## Error Handling Patterns

### Early Return Pattern

The most common Go pattern - handle errors immediately:

```go
func processFile(path string) error {
    file, err := os.Open(path)
    if err != nil {
        return fmt.Errorf("opening file: %w", err)
    }
    defer file.Close()
    
    data, err := io.ReadAll(file)
    if err != nil {
        return fmt.Errorf("reading file: %w", err)
    }
    
    result, err := parseData(data)
    if err != nil {
        return fmt.Errorf("parsing data: %w", err)
    }
    
    if err := saveResult(result); err != nil {
        return fmt.Errorf("saving result: %w", err)
    }
    
    return nil
}
```

### Error Handling in Loops

```go
func processFiles(paths []string) error {
    var errs []error
    
    for _, path := range paths {
        if err := processFile(path); err != nil {
            // Collect errors instead of returning immediately
            errs = append(errs, fmt.Errorf("file %s: %w", path, err))
        }
    }
    
    if len(errs) > 0 {
        // Return combined error
        return fmt.Errorf("processed %d files with %d errors: %v", 
            len(paths), len(errs), errs)
    }
    
    return nil
}

// Alternative: Stop on first error
func processFilesStopOnError(paths []string) error {
    for i, path := range paths {
        if err := processFile(path); err != nil {
            return fmt.Errorf("file %d/%d (%s): %w", 
                i+1, len(paths), path, err)
        }
    }
    return nil
}
```

### Retry Pattern

```go
type RetryConfig struct {
    MaxAttempts int
    InitialDelay time.Duration
    MaxDelay     time.Duration
    Multiplier   float64
}

func withRetry(fn func() error, cfg RetryConfig) error {
    var lastErr error
    delay := cfg.InitialDelay
    
    for attempt := 1; attempt <= cfg.MaxAttempts; attempt++ {
        err := fn()
        if err == nil {
            return nil
        }
        
        lastErr = err
        
        // Check if error is retryable
        var retryable RetryableError
        if !errors.As(err, &retryable) {
            // Not retryable, return immediately
            return err
        }
        
        if attempt == cfg.MaxAttempts {
            break
        }
        
        // Wait before retry
        time.Sleep(delay)
        
        // Exponential backoff
        delay = time.Duration(float64(delay) * cfg.Multiplier)
        if delay > cfg.MaxDelay {
            delay = cfg.MaxDelay
        }
    }
    
    return fmt.Errorf("failed after %d attempts: %w", cfg.MaxAttempts, lastErr)
}
```

### Cleanup on Error

```go
func createResources() (err error) {
    // Track what needs cleanup
    var (
        file *os.File
        conn net.Conn
    )
    
    // Cleanup function
    cleanup := func() {
        if file != nil {
            file.Close()
        }
        if conn != nil {
            conn.Close()
        }
    }
    
    // Ensure cleanup on error
    defer func() {
        if err != nil {
            cleanup()
        }
    }()
    
    // Create resources
    file, err = os.Create("data.txt")
    if err != nil {
        return fmt.Errorf("creating file: %w", err)
    }
    
    conn, err = net.Dial("tcp", "localhost:8080")
    if err != nil {
        return fmt.Errorf("connecting: %w", err)
    }
    
    // Use resources...
    
    return nil
}
```

## Error Design Patterns

### Layered Error Handling

Different layers of your application should add appropriate context:

```go
// Data layer
func (db *Database) GetUser(id string) (*User, error) {
    var user User
    err := db.QueryRow("SELECT * FROM users WHERE id = ?", id).Scan(&user)
    if err == sql.ErrNoRows {
        return nil, ErrNotFound
    }
    if err != nil {
        return nil, fmt.Errorf("query user %s: %w", id, err)
    }
    return &user, nil
}

// Service layer
func (s *UserService) GetUserProfile(id string) (*Profile, error) {
    user, err := s.db.GetUser(id)
    if err != nil {
        if errors.Is(err, ErrNotFound) {
            return nil, NewAPIError(404, "USER_NOT_FOUND", "User not found")
        }
        return nil, fmt.Errorf("fetching user: %w", err)
    }
    
    // Build profile...
    return profile, nil
}

// HTTP layer
func (h *Handler) GetUser(w http.ResponseWriter, r *http.Request) {
    profile, err := h.service.GetUserProfile(userID)
    if err != nil {
        var apiErr *APIError
        if errors.As(err, &apiErr) {
            h.respondError(w, apiErr)
            return
        }
        
        // Log internal error, return generic message
        h.logger.Error("get user profile", "error", err)
        h.respondError(w, NewAPIError(500, "INTERNAL_ERROR", "Internal server error"))
        return
    }
    
    h.respondJSON(w, profile)
}
```

### Error Groups

When you need to handle multiple concurrent operations:

```go
import "golang.org/x/sync/errgroup"

func fetchAllData(ctx context.Context, userID string) (*AllData, error) {
    g, ctx := errgroup.WithContext(ctx)
    
    var (
        user    *User
        posts   []*Post
        friends []*User
    )
    
    g.Go(func() error {
        var err error
        user, err = fetchUser(ctx, userID)
        return err
    })
    
    g.Go(func() error {
        var err error
        posts, err = fetchUserPosts(ctx, userID)
        return err
    })
    
    g.Go(func() error {
        var err error
        friends, err = fetchUserFriends(ctx, userID)
        return err
    })
    
    if err := g.Wait(); err != nil {
        return nil, fmt.Errorf("fetching data: %w", err)
    }
    
    return &AllData{
        User:    user,
        Posts:   posts,
        Friends: friends,
    }, nil
}
```

### Circuit Breaker Pattern

Prevent cascading failures:

```go
type CircuitBreaker struct {
    maxFailures  int
    resetTimeout time.Duration
    
    mu           sync.Mutex
    failures     int
    lastFailTime time.Time
    state        State
}

type State int

const (
    StateClosed State = iota
    StateOpen
    StateHalfOpen
)

func (cb *CircuitBreaker) Call(fn func() error) error {
    cb.mu.Lock()
    defer cb.mu.Unlock()
    
    // Check if we should attempt
    if cb.state == StateOpen {
        if time.Since(cb.lastFailTime) < cb.resetTimeout {
            return ErrCircuitOpen
        }
        cb.state = StateHalfOpen
    }
    
    // Execute function
    err := fn()
    
    if err != nil {
        cb.failures++
        cb.lastFailTime = time.Now()
        
        if cb.failures >= cb.maxFailures {
            cb.state = StateOpen
            return fmt.Errorf("circuit open: %w", err)
        }
        
        return err
    }
    
    // Success - reset
    cb.failures = 0
    cb.state = StateClosed
    return nil
}
```

## Testing Error Paths

Good error handling must be tested:

```go
func TestProcessOrder_Errors(t *testing.T) {
    tests := []struct {
        name      string
        setupMock func(*MockDB)
        wantErr   string
    }{
        {
            name: "order not found",
            setupMock: func(m *MockDB) {
                m.On("GetOrder", "123").Return(nil, ErrNotFound)
            },
            wantErr: "processing order 123: not found",
        },
        {
            name: "invalid order",
            setupMock: func(m *MockDB) {
                m.On("GetOrder", "123").Return(&Order{
                    Total: -10,
                }, nil)
            },
            wantErr: "invalid order 123: negative total",
        },
        {
            name: "payment failed",
            setupMock: func(m *MockDB) {
                m.On("GetOrder", "123").Return(&Order{
                    Total: 100,
                }, nil)
                m.On("ChargePayment", mock.Anything).Return(
                    errors.New("insufficient funds"))
            },
            wantErr: "payment failed for order 123 ($100.00): insufficient funds",
        },
    }
    
    for _, tt := range tests {
        t.Run(tt.name, func(t *testing.T) {
            mock := new(MockDB)
            tt.setupMock(mock)
            
            service := &OrderService{db: mock}
            err := service.ProcessOrder("123")
            
            if err == nil {
                t.Fatal("expected error, got nil")
            }
            
            if err.Error() != tt.wantErr {
                t.Errorf("got error %q, want %q", err.Error(), tt.wantErr)
            }
            
            mock.AssertExpectations(t)
        })
    }
}
```

## Common Mistakes and How to Avoid Them

### Mistake 1: Ignoring Errors

```go
// ❌ Never ignore errors silently
result, _ := strconv.Atoi(input)

// ✅ Always handle or explicitly ignore
result, err := strconv.Atoi(input)
if err != nil {
    // Handle error
    return 0, fmt.Errorf("invalid number: %w", err)
}

// ✅ If you must ignore, be explicit
_ = os.Remove(tempFile)  // Best effort cleanup
```

### Mistake 2: Overusing Panic

```go
// ❌ Don't panic for normal errors
func divide(a, b float64) float64 {
    if b == 0 {
        panic("division by zero")  // Wrong!
    }
    return a / b
}

// ✅ Return errors for expected failures
func divide(a, b float64) (float64, error) {
    if b == 0 {
        return 0, errors.New("division by zero")
    }
    return a / b, nil
}

// ✅ Panic only for programming errors
func MustCompile(pattern string) *Regexp {
    re, err := Compile(pattern)
    if err != nil {
        panic(fmt.Sprintf("regexp: Compile(%q): %v", pattern, err))
    }
    return re
}
```

### Mistake 3: Losing Error Context

```go
// ❌ Returning error without context
if err != nil {
    return err  // Where did this come from?
}

// ✅ Always add context
if err != nil {
    return fmt.Errorf("connecting to database: %w", err)
}
```

### Mistake 4: String Comparison

```go
// ❌ Don't compare error strings
if err.Error() == "not found" {
    // Fragile!
}

// ✅ Use sentinel errors or type assertions
if errors.Is(err, ErrNotFound) {
    // Robust
}
```

## Best Practices

### 1. Create Errors at the Boundary

```go
// ✅ Define errors where they're detected
package database

var (
    ErrNotFound      = errors.New("not found")
    ErrDuplicate     = errors.New("duplicate entry")
    ErrInvalidQuery  = errors.New("invalid query")
)
```

### 2. Wrap Errors with Context

```go
// ✅ Add context at each layer
func (s *Service) CreateUser(req CreateUserRequest) error {
    if err := s.validate(req); err != nil {
        return fmt.Errorf("validating user data: %w", err)
    }
    
    user := s.buildUser(req)
    
    if err := s.db.Insert(user); err != nil {
        return fmt.Errorf("storing user %s: %w", user.Email, err)
    }
    
    if err := s.sendWelcomeEmail(user); err != nil {
        // Non-critical error - log but don't fail
        s.logger.Error("failed to send welcome email", 
            "user", user.Email, "error", err)
    }
    
    return nil
}
```

### 3. Design for Error Handling

```go
// ✅ Make error handling explicit in API design
type Result[T any] struct {
    Value T
    Err   error
}

func (r Result[T]) Ok() bool {
    return r.Err == nil
}

func (r Result[T]) Unwrap() (T, error) {
    return r.Value, r.Err
}

// Usage
result := fetchData()
if !result.Ok() {
    return result.Err
}
data := result.Value
```

### 4. Document Error Behavior

```go
// ProcessBatch processes a batch of items concurrently.
// It returns an error if any item fails to process.
// The error will contain details about which items failed.
//
// Possible errors:
//   - ErrInvalidInput: if items is nil or empty
//   - ErrRateLimit: if rate limit is exceeded
//   - Processing errors wrapped with item context
func ProcessBatch(items []Item) error {
    // Implementation
}
```

## Real-World Example: Turbo Error Handling

Let's implement comprehensive error handling for a Turbo component:

```go
package turbo

import (
    "context"
    "errors"
    "fmt"
    "time"
)

// Sentinel errors
var (
    ErrJobNotFound    = errors.New("job not found")
    ErrJobCancelled   = errors.New("job cancelled")
    ErrQueueFull      = errors.New("queue full")
    ErrWorkerStopped  = errors.New("worker stopped")
)

// JobError provides detailed job execution errors
type JobError struct {
    JobID     string
    Stage     string
    Err       error
    Timestamp time.Time
    Retryable bool
}

func (e JobError) Error() string {
    return fmt.Sprintf("job %s failed at %s: %v", e.JobID, e.Stage, e.Err)
}

func (e JobError) Unwrap() error {
    return e.Err
}

// Queue manages job processing with comprehensive error handling
type Queue struct {
    jobs     chan Job
    errors   chan error
    workers  int
    maxRetry int
}

func (q *Queue) Submit(ctx context.Context, job Job) error {
    select {
    case q.jobs <- job:
        return nil
    case <-ctx.Done():
        return fmt.Errorf("submitting job %s: %w", job.ID, ctx.Err())
    default:
        return ErrQueueFull
    }
}

func (q *Queue) Process(ctx context.Context, job Job) error {
    // Validate job
    if err := q.validateJob(job); err != nil {
        return JobError{
            JobID:     job.ID,
            Stage:     "validation",
            Err:       err,
            Timestamp: time.Now(),
            Retryable: false,
        }
    }
    
    // Execute with retry
    err := q.executeWithRetry(ctx, job)
    if err != nil {
        // Check if it's already a JobError
        var jobErr JobError
        if errors.As(err, &jobErr) {
            return jobErr
        }
        
        // Wrap other errors
        return JobError{
            JobID:     job.ID,
            Stage:     "execution",
            Err:       err,
            Timestamp: time.Now(),
            Retryable: isRetryable(err),
        }
    }
    
    return nil
}

func (q *Queue) executeWithRetry(ctx context.Context, job Job) error {
    var lastErr error
    
    for attempt := 0; attempt <= q.maxRetry; attempt++ {
        if attempt > 0 {
            // Exponential backoff
            delay := time.Duration(attempt) * time.Second
            select {
            case <-time.After(delay):
            case <-ctx.Done():
                return ctx.Err()
            }
        }
        
        err := job.Execute(ctx)
        if err == nil {
            return nil
        }
        
        lastErr = err
        
        // Don't retry certain errors
        if errors.Is(err, context.Canceled) ||
           errors.Is(err, ErrJobCancelled) ||
           !isRetryable(err) {
            return err
        }
    }
    
    return fmt.Errorf("failed after %d attempts: %w", q.maxRetry+1, lastErr)
}

func isRetryable(err error) bool {
    // Network errors are retryable
    var netErr net.Error
    if errors.As(err, &netErr) {
        return netErr.Temporary()
    }
    
    // Check for explicit retryable errors
    var retryable RetryableError
    return errors.As(err, &retryable)
}

// Error aggregation for batch operations
type BatchError struct {
    Errors []error
    Total  int
    Failed int
}

func (e BatchError) Error() string {
    return fmt.Sprintf("batch processing failed: %d/%d jobs failed",
        e.Failed, e.Total)
}

func (q *Queue) ProcessBatch(ctx context.Context, jobs []Job) error {
    results := make(chan error, len(jobs))
    
    for _, job := range jobs {
        go func(j Job) {
            results <- q.Process(ctx, j)
        }(job)
    }
    
    var errors []error
    for i := 0; i < len(jobs); i++ {
        if err := <-results; err != nil {
            errors = append(errors, err)
        }
    }
    
    if len(errors) > 0 {
        return BatchError{
            Errors: errors,
            Total:  len(jobs),
            Failed: len(errors),
        }
    }
    
    return nil
}
```

## Summary

You've mastered Go's approach to error handling:

1. **Errors are values** - Handle them like any other value
2. **Be explicit** - Don't hide errors, handle them
3. **Add context** - Wrap errors with meaningful information
4. **Design for errors** - Make error handling a first-class concern
5. **Test error paths** - Errors are part of your API
6. **Use patterns wisely** - Apply retry, circuit breaker, etc. where appropriate

## What's Next?

Ready to ensure your error-free code actually works? Continue to [Testing Strategies](05-testing-strategies.md) to learn Go's approach to testing.

---

*"Don't just check errors, handle them gracefully."* - Dave Cheney, Go Proverb

Ready to test? → [Continue to Testing Strategies](05-testing-strategies.md)