# Turbo CLI Design Document

## Overview
Turbo is a CLI tool designed to simplify data pipeline image creation by automating the generation of required directory structures and files from JSON metadata. It extends beyond file generation to provide a comprehensive pipeline development toolkit including API integration, dataset registration, and modeling workflows.

## Problem Statement
- Teams need to build images for data pipelines with complex JSON artifacts and directory structures
- Current process requires manual creation of multiple files and configurations
- Teams juggle multiple tools (Swagger, Postman) for API interactions
- Dataset registration and modeling workflows are tedious manual processes

## Solution
A Go-based CLI tool that:
- Reads JSON configuration from S3 or local files
- Generates required directory structures and files
- Integrates with version control systems
- Provides unified interface for pipeline-related APIs
- Automates dataset registration and modeling workflows

## Architecture

### Technology Stack
- **Language**: Go
- **Distribution**: Standalone binary (with future package distribution capability)
- **CLI Framework**: Cobra/Viper
- **AWS Integration**: AWS SDK Go v2
- **Excel Generation**: excelize/v2
- **Git Operations**: go-git

### Project Structure
```
turbo/
├── cmd/
│   ├── root.go          # turbo
│   ├── generate.go      # turbo generate
│   ├── api.go          # turbo api
│   └── files.go        # turbo files
├── pkg/
│   ├── aws/            # S3, credential handling
│   ├── git/            # git operations
│   ├── pipeline/       # JSON processing, file generation
│   └── api/            # API client functionality
├── go.mod
└── main.go
```

## Core Features

### 1. File Generation (`turbo generate`)
- **Input**: JSON configuration from S3 or local path
- **Process**: 
  - Auto-detect repository root
  - Validate JSON schema
  - Generate required files maintaining repo integrity
  - Create new files, replace only explicitly requested
- **Output**: Complete directory structure ready for pipeline image build

### 2. API Integration (`turbo api`)
- **External APIs**:
  - Vendor allowlisting
  - Dataset registration automation
- **Internal APIs**:
  - CRUD operations for datasets
  - Pipeline execution
  - Individual process runs (registration, dry run)

### 3. File Management (`turbo files`)
- List published files by environment/pipeline
- Diff local vs remote files
- Validate file structures

## Configuration

### JSON Configuration Contains:
- Pipeline metadata
- Dataset definitions
- Model configurations
- PII column designations

### CLI Arguments Handle:
- Execution options (--dry-run, --output-dir)
- Git integration (--git-branch, --git-commit)
- AWS profiles (--aws-profile)
- Verbosity (--verbose/-v, --quiet/-q)

### Environment Variables:
- API endpoints
- Default AWS regions
- Authentication tokens

## Authentication & Security

### AWS Authentication
- Leverages existing PCL (internal tool) credentials
- Supports multiple AWS accounts via profiles
- Standard AWS credential chain (env vars, ~/.aws/credentials)

### API Authentication
- Pluggable authentication system
- Support for:
  - AWS SigV4
  - API keys
  - OAuth tokens
- Environment-specific configurations

### Security Considerations
- No sensitive data in JSON (metadata only)
- PII column designations handled appropriately
- Audit trail for all operations
- Broad S3 bucket access support

## User Experience

### Command Examples
```bash
# Generate pipeline files
turbo generate --config s3://bucket/pipeline-config.json

# List models in production
turbo api list-models --env prod --aws-profile prod

# Compare local and published files
turbo files diff --local ./output --remote s3://published/

# Dry run with verbose output
turbo generate --config config.json --dry-run -v
```

### IDE Integration
- Teams use CLI within their IDE for real-time file manipulation visibility
- Clear, parseable output formats
- Support for --json flag for programmatic use
- Standard file path formats for IDE navigation

### Error Handling
- Dry-run mode for previewing changes
- Rollback capability
- Progress indicators for long operations
- Clear error messages with actionable solutions

## Git Integration
- Optional auto-commit and push capabilities
- Configurable branch naming strategies
- Handle merge conflicts and dirty working trees gracefully
- Not highest priority - will evolve based on usage

## Output Formats
- JSON
- YAML
- Excel (xlsx) for modeling API requirements
- Formatted tables for human reading

## Versioning & Compatibility
- Embedded schema version in JSON
- Binary version embedded at build time
- Backwards compatibility for 2-3 schema versions
- Clear upgrade path documentation

## Distribution & Installation
- Initial: Downloadable binary
- Future: Internal package registry
- Design supports both distribution methods

## Documentation Strategy
1. **Built-in Help**: Comprehensive help for all commands
2. **README.md**: Quick start guide and common examples
3. **Wiki/Confluence**: Detailed workflows, API documentation, troubleshooting

## Audit Trail
Simple JSON-based audit log in `~/.turbo/audit.log`:
```json
{
  "timestamp": "2024-01-01T12:00:00Z",
  "user": "username",
  "action": "generate",
  "input": "s3://bucket/config.json",
  "output": "/path/to/repo",
  "status": "success"
}
```

## Implementation Priority
1. **Phase 1**: Core file generation from JSON
2. **Phase 2**: Dataset registration automation
3. **Phase 3**: Modeling workflow with Excel generation
4. **Phase 4**: Full pipeline execution capabilities
5. **Phase 5**: Git integration and advanced features

## Future Enhancements
- LLM integration for intelligent assistance
- Extended API coverage
- Advanced caching mechanisms
- LSP integration for deeper IDE support

## Success Criteria
- Reduces pipeline setup time from hours to minutes
- Eliminates manual errors in file generation
- Provides single interface for all pipeline operations
- High adoption rate among ETL engineers and SWEs

## Team Information
- **Users**: ETL engineers, software engineers
- **Tech Stack**: Java, Python
- **Environment**: Enterprise with standardized data pipeline structures