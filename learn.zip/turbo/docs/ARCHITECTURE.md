# Turbo Architecture

## Overview

Turbo is a CLI tool that accelerates data pipeline development by automating file generation and configuration management. It integrates with enterprise data infrastructure to eliminate manual setup steps and reduce configuration errors.

## Design Philosophy

Turbo follows a hexagonal architecture (ports and adapters) pattern to maintain clear separation between business logic and external dependencies. This enables easy testing, modification, and extension of the system.

## Core Architecture Patterns

### Layered Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    CLI Layer (cmd/)                     │
│                 Cobra Commands & Flags                  │
├─────────────────────────────────────────────────────────┤
│                 Application Layer (pkg/)                │
│              Business Logic & Orchestration             │
├─────────────────────────────────────────────────────────┤
│                  Domain Layer (pkg/)                    │
│               Core Models & Interfaces                  │
├─────────────────────────────────────────────────────────┤
│              Infrastructure Layer (pkg/)                │
│            External Services & Adapters                 │
└─────────────────────────────────────────────────────────┘
```

### Package Structure

```
turbo/
├── cmd/                    # CLI commands
│   ├── root.go            # Root command setup
│   ├── generate.go        # Generate command
│   ├── list.go           # List configurations
│   ├── show.go           # Show configuration details
│   └── validate.go        # Validate configuration
│
├── pkg/                   # Core packages
│   ├── config/           # Configuration management
│   │   ├── config.go     # Config struct and validation
│   │   ├── loader.go     # Config loading logic
│   │   └── resolver.go   # Environment resolution
│   │
│   ├── pipeline/         # Pipeline domain logic
│   │   ├── models.go     # Domain models
│   │   ├── parser.go     # JSON parsing
│   │   ├── generator.go  # File generation
│   │   └── validator.go  # Schema validation
│   │
│   ├── datastore/        # Data access layer
│   │   ├── interface.go  # Datastore interface
│   │   ├── dynamodb.go   # DynamoDB implementation
│   │   ├── cache.go      # Caching layer
│   │   └── models.go     # Data models
│   │
│   ├── api/             # API Gateway client
│   │   ├── client.go    # HTTP client with retry
│   │   ├── auth.go      # PCL/AWS authentication
│   │   ├── endpoints.go  # API endpoint definitions
│   │   └── models.go    # Request/response models
│   │
│   ├── git/             # Git operations
│   │   ├── client.go    # Git client wrapper
│   │   └── workflow.go  # Branch/commit strategies
│   │
│   └── audit/           # Audit logging
│       └── logger.go    # Audit trail
│
├── internal/            # Internal packages
│   ├── telemetry/      # Metrics and tracing
│   ├── errors/         # Custom error types
│   └── utils/          # Shared utilities
│
└── test/               # Test utilities
    ├── fixtures/       # Test data
    ├── mocks/         # Generated mocks
    └── e2e/           # End-to-end tests
```

## Key Design Decisions

### Interface-Driven Design

All major components are defined by interfaces:

```go
// Datastore interface for configuration management
type Datastore interface {
    GetConfig(ctx context.Context, pipeline string, version string) (*Config, error)
    ListConfigs(ctx context.Context, filter Filter) ([]*ConfigMeta, error)
    GetLatestVersion(ctx context.Context, pipeline string) (string, error)
}

// API Gateway client interface
type APIClient interface {
    GetPipelineConfig(ctx context.Context, name, version string) (*PipelineConfig, error)
    ListPipelineConfigs(ctx context.Context, opts ListOptions) ([]*PipelineConfig, error)
    ValidateConfig(ctx context.Context, config *PipelineConfig) (*ValidationResult, error)
}

// Pipeline generator interface
type Generator interface {
    Generate(ctx context.Context, config *Config) error
    Validate(ctx context.Context, config *Config) error
}
```

### Dependency Injection

Dependencies are injected through constructors:

```go
type Service struct {
    storage   Storage
    generator Generator
    logger    *slog.Logger
}

func NewService(storage Storage, generator Generator, logger *slog.Logger) *Service {
    return &Service{
        storage:   storage,
        generator: generator,
        logger:    logger,
    }
}
```

### Context Propagation

All operations accept context for cancellation and value propagation:

```go
func (s *Service) ProcessPipeline(ctx context.Context, configPath string) error {
    ctx, span := tracer.Start(ctx, "ProcessPipeline")
    defer span.End()
    
    // Context flows through all operations
    config, err := s.loadConfig(ctx, configPath)
    if err != nil {
        return fmt.Errorf("loading config: %w", err)
    }
    
    return s.generator.Generate(ctx, config)
}
```

### Error Handling

Structured errors with wrapping for context:

```go
var (
    ErrConfigNotFound = errors.New("configuration not found")
    ErrInvalidSchema  = errors.New("invalid schema")
)

type ValidationError struct {
    Field   string
    Message string
}

func (e ValidationError) Error() string {
    return fmt.Sprintf("validation failed for %s: %s", e.Field, e.Message)
}
```

## Observability

### Structured Logging

Using slog for structured, contextual logging:

```go
logger.Info("processing pipeline",
    slog.String("config", configPath),
    slog.String("environment", env),
    slog.Duration("duration", time.Since(start)),
)
```

### Metrics

OpenTelemetry for metrics collection:

```go
var (
    pipelineCounter = metric.NewInt64Counter(
        "turbo.pipeline.processed",
        metric.WithDescription("Number of pipelines processed"),
    )
)
```

### Tracing

Distributed tracing for API calls:

```go
ctx, span := tracer.Start(ctx, "api.RegisterDataset",
    trace.WithAttributes(
        attribute.String("dataset.name", name),
        attribute.String("environment", env),
    ),
)
defer span.End()
```

## Security Considerations

### Authentication

Leverages existing enterprise authentication via PCL:

```go
// Uses AWS credentials from PCL authentication
type AWSAuth struct {
    session *session.Session
}

func NewAWSAuth() (*AWSAuth, error) {
    // Automatically uses credentials from PCL
    sess, err := session.NewSession(&aws.Config{
        Region: aws.String("us-east-1"),
    })
    if err != nil {
        return nil, fmt.Errorf("failed to create AWS session: %w", err)
    }
    
    return &AWSAuth{session: sess}, nil
}
```

### Input Validation

All inputs validated at boundaries:

```go
func ValidateConfig(config *Config) error {
    if err := validateRequired(config); err != nil {
        return err
    }
    
    if err := validateSchema(config); err != nil {
        return err
    }
    
    return validateBusinessRules(config)
}
```

## Testing Strategy

### Unit Tests

Focus on testing individual components in isolation:

```go
func TestGenerator_Generate(t *testing.T) {
    mockStorage := mocks.NewMockStorage(t)
    generator := pipeline.NewGenerator(mockStorage)
    
    // Test specific scenarios
}
```

### Integration Tests

Test component interactions:

```go
func TestPipelineIntegration(t *testing.T) {
    // Use real implementations with test backends
}
```

### End-to-End Tests

Test complete workflows:

```go
func TestGenerateCommand(t *testing.T) {
    // Execute actual CLI commands
}
```

## Performance Considerations

### Concurrency

Parallel processing where applicable:

```go
func ProcessFiles(ctx context.Context, files []string) error {
    g, ctx := errgroup.WithContext(ctx)
    
    for _, file := range files {
        file := file // capture loop variable
        g.Go(func() error {
            return processFile(ctx, file)
        })
    }
    
    return g.Wait()
}
```

### Resource Pooling

Connection and worker pools:

```go
type ClientPool struct {
    clients chan *Client
}

func (p *ClientPool) Get() *Client {
    select {
    case client := <-p.clients:
        return client
    default:
        return p.create()
    }
}
```

### Caching

In-memory caching for frequently accessed data:

```go
type Cache struct {
    mu    sync.RWMutex
    items map[string]cacheItem
}
```

## Data Flow

### Configuration Retrieval

```
User Input → CLI Command → API Gateway → DynamoDB → Response
                              ↓
                         Authentication (PCL/AWS)
```

### File Generation

```
Configuration → Parser → Validator → Generator → File System
                                        ↓
                                   Git Operations
```

## Key Integration Points

### DynamoDB Schema

Pipeline configurations are stored with the following structure:

```go
type PipelineConfig struct {
    PipelineName    string            `dynamodbav:"pipeline_name,hash"`
    Version         string            `dynamodbav:"version,range"`
    Configuration   json.RawMessage   `dynamodbav:"configuration"`
    CreatedAt       time.Time         `dynamodbav:"created_at"`
    CreatedBy       string            `dynamodbav:"created_by"`
    Status          string            `dynamodbav:"status"`
    Tags            map[string]string `dynamodbav:"tags"`
}
```

### API Gateway Endpoints

```
GET  /pipeline-configs                    # List all configs
GET  /pipeline-configs/{name}             # Get latest version
GET  /pipeline-configs/{name}/versions    # List all versions
GET  /pipeline-configs/{name}/v/{version} # Get specific version
POST /pipeline-configs/validate           # Validate configuration
```

## Extension Points

### Command Plugins

New commands can be added without modifying core:

```go
func init() {
    rootCmd.AddCommand(newCustomCommand())
}
```

### Data Sources

New data source implementations via interface:

```go
type S3Datastore struct{}

func (s *S3Datastore) GetConfig(ctx context.Context, pipeline, version string) (*Config, error) {
    // S3 fallback implementation
}
```

### Output Formats

Pluggable formatters for different file types:

```go
type Generator interface {
    GenerateDockerfile(config *Config) error
    GenerateConfigFiles(config *Config) error
    GenerateScripts(config *Config) error
}
```

This architecture ensures maintainability, testability, and extensibility while meeting enterprise-grade requirements.