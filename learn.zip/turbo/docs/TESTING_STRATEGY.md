# Testing Strategy

## Overview

This document outlines the comprehensive testing approach for the Turbo CLI tool, ensuring reliability, maintainability, and confidence in production deployments.

## Testing Philosophy

- **Test Pyramid**: More unit tests, fewer integration tests, minimal E2E tests
- **Test-Driven Development**: Write tests before implementation
- **Behavior-Driven**: Tests describe what the system does, not how
- **Fast Feedback**: Tests run quickly to enable rapid development
- **Deterministic**: Tests produce consistent results

## Test Categories

### Unit Tests (70% of tests)

Focus on testing individual functions and methods in isolation.

#### Characteristics
- Fast execution (< 100ms per test)
- No external dependencies
- Use mocks for collaborators
- Test edge cases and error conditions

#### Example Structure
```go
func TestParser_ParseConfig(t *testing.T) {
    tests := []struct {
        name    string
        input   string
        want    *Config
        wantErr error
    }{
        {
            name:  "valid config",
            input: `{"version": "1.0", "pipeline": "test"}`,
            want:  &Config{Version: "1.0", Pipeline: "test"},
        },
        {
            name:    "invalid json",
            input:   `{invalid}`,
            wantErr: ErrInvalidJSON,
        },
    }
    
    for _, tt := range tests {
        t.Run(tt.name, func(t *testing.T) {
            parser := NewParser()
            got, err := parser.ParseConfig(tt.input)
            
            if !errors.Is(err, tt.wantErr) {
                t.Errorf("ParseConfig() error = %v, wantErr %v", err, tt.wantErr)
            }
            
            if !reflect.DeepEqual(got, tt.want) {
                t.Errorf("ParseConfig() = %v, want %v", got, tt.want)
            }
        })
    }
}
```

### Integration Tests (20% of tests)

Test interactions between components with real implementations.

#### Characteristics
- Test component boundaries
- Use test databases/services
- May use test containers
- Focus on contract testing

#### Example
```go
func TestS3Storage_Integration(t *testing.T) {
    if testing.Short() {
        t.Skip("skipping integration test")
    }
    
    // Setup test S3 bucket
    storage := setupTestS3Storage(t)
    defer cleanupTestBucket(t)
    
    ctx := context.Background()
    
    // Test operations
    err := storage.Put(ctx, "test-key", []byte("test-data"))
    require.NoError(t, err)
    
    data, err := storage.Get(ctx, "test-key")
    require.NoError(t, err)
    assert.Equal(t, "test-data", string(data))
}
```

### End-to-End Tests (10% of tests)

Test complete user workflows through the CLI.

#### Characteristics
- Execute actual CLI commands
- Test full scenarios
- Verify file outputs
- May be slower to execute

#### Example
```go
func TestGenerateCommand_E2E(t *testing.T) {
    if testing.Short() {
        t.Skip("skipping e2e test")
    }
    
    tempDir := t.TempDir()
    configFile := filepath.Join(tempDir, "config.json")
    
    // Create test config
    writeTestConfig(t, configFile)
    
    // Run command
    cmd := exec.Command("turbo", "generate", "--config", configFile)
    output, err := cmd.CombinedOutput()
    
    require.NoError(t, err, "command failed: %s", output)
    
    // Verify generated files
    assertFileExists(t, filepath.Join(tempDir, "output/pipeline.yaml"))
}
```

## Testing Patterns

### Table-Driven Tests

Use table-driven tests for comprehensive coverage:

```go
func TestValidateField(t *testing.T) {
    tests := []struct {
        name      string
        field     string
        value     interface{}
        wantValid bool
    }{
        {"valid string", "name", "test", true},
        {"empty string", "name", "", false},
        {"nil value", "name", nil, false},
        {"valid number", "count", 42, true},
        {"negative number", "count", -1, false},
    }
    
    for _, tt := range tests {
        t.Run(tt.name, func(t *testing.T) {
            got := ValidateField(tt.field, tt.value)
            assert.Equal(t, tt.wantValid, got)
        })
    }
}
```

### Mock Generation

Use mockery for interface mocks:

```bash
# Generate mocks
mockery --all --dir pkg --output test/mocks
```

```go
func TestService_ProcessPipeline(t *testing.T) {
    mockStorage := mocks.NewMockStorage(t)
    mockGenerator := mocks.NewMockGenerator(t)
    
    mockStorage.On("Get", mock.Anything, "config.json").
        Return([]byte(`{"version": "1.0"}`), nil)
    
    mockGenerator.On("Generate", mock.Anything, mock.Anything).
        Return(nil)
    
    service := NewService(mockStorage, mockGenerator)
    err := service.ProcessPipeline(context.Background(), "config.json")
    
    assert.NoError(t, err)
    mockStorage.AssertExpectations(t)
    mockGenerator.AssertExpectations(t)
}
```

### Test Fixtures

Organize test data in fixtures:

```
test/
├── fixtures/
│   ├── configs/
│   │   ├── valid_pipeline.json
│   │   ├── invalid_schema.json
│   │   └── complex_pipeline.json
│   ├── expected/
│   │   ├── generated_files/
│   │   └── api_responses/
│   └── golden/
│       └── output_snapshots/
```

### Golden Files

Use golden files for complex output validation:

```go
func TestGenerator_Output(t *testing.T) {
    generator := NewGenerator()
    output := generator.Generate(testConfig)
    
    golden := filepath.Join("test/golden", t.Name()+".golden")
    
    if *updateGolden {
        os.WriteFile(golden, output, 0644)
    }
    
    expected, _ := os.ReadFile(golden)
    assert.Equal(t, string(expected), string(output))
}
```

## Test Helpers

### Common Test Utilities

```go
// test/helpers.go
func SetupTestLogger(t *testing.T) *slog.Logger {
    return slog.New(slog.NewTextHandler(io.Discard, nil))
}

func SetupTestContext(t *testing.T) context.Context {
    ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
    t.Cleanup(cancel)
    return ctx
}

func AssertErrorContains(t *testing.T, err error, substring string) {
    t.Helper()
    if err == nil {
        t.Errorf("expected error containing %q, got nil", substring)
        return
    }
    if !strings.Contains(err.Error(), substring) {
        t.Errorf("error %q should contain %q", err.Error(), substring)
    }
}
```

### Test Builders

Use builder pattern for complex test data:

```go
type ConfigBuilder struct {
    config *Config
}

func NewConfigBuilder() *ConfigBuilder {
    return &ConfigBuilder{
        config: &Config{
            Version: "1.0",
        },
    }
}

func (b *ConfigBuilder) WithPipeline(name string) *ConfigBuilder {
    b.config.Pipeline = name
    return b
}

func (b *ConfigBuilder) Build() *Config {
    return b.config
}

// Usage
config := NewConfigBuilder().
    WithPipeline("test").
    WithDataset("users").
    Build()
```

## Performance Testing

### Benchmarks

Include benchmarks for critical paths:

```go
func BenchmarkParser_ParseLargeConfig(b *testing.B) {
    largeConfig := generateLargeConfig()
    parser := NewParser()
    
    b.ResetTimer()
    for i := 0; i < b.N; i++ {
        _, err := parser.Parse(largeConfig)
        if err != nil {
            b.Fatal(err)
        }
    }
}
```

### Load Testing

Test concurrent usage:

```go
func TestConcurrentOperations(t *testing.T) {
    service := NewService()
    
    var wg sync.WaitGroup
    errors := make(chan error, 100)
    
    for i := 0; i < 100; i++ {
        wg.Add(1)
        go func(id int) {
            defer wg.Done()
            if err := service.Process(fmt.Sprintf("config-%d", id)); err != nil {
                errors <- err
            }
        }(i)
    }
    
    wg.Wait()
    close(errors)
    
    for err := range errors {
        t.Errorf("concurrent operation failed: %v", err)
    }
}
```

## Test Organization

### Directory Structure

```
pkg/pipeline/
├── parser.go
├── parser_test.go
├── generator.go
├── generator_test.go
├── testdata/
│   ├── configs/
│   └── expected/
└── benchmark_test.go
```

### Test Tags

Use build tags for different test types:

```go
//go:build integration
// +build integration

func TestDatabaseIntegration(t *testing.T) {
    // Integration test code
}
```

Run specific test types:
```bash
# Unit tests only
go test ./...

# Include integration tests
go test -tags=integration ./...

# E2E tests
go test -tags=e2e ./test/e2e/...
```

## Continuous Integration

### Test Pipeline

```yaml
test:
  stage: test
  parallel:
    matrix:
      - TEST_TYPE: unit
        COVERAGE: true
      - TEST_TYPE: integration
        TAGS: integration
      - TEST_TYPE: e2e
        TAGS: e2e
  script:
    - go test -tags=$TAGS -coverprofile=coverage.out ./...
    - go tool cover -html=coverage.out -o coverage.html
```

### Coverage Requirements

- Overall coverage: > 80%
- Critical paths: > 90%
- New code: > 85%

### Test Reports

Generate detailed test reports:

```bash
# JUnit format for CI
go test -v ./... | go-junit-report > test-report.xml

# Coverage report
go test -coverprofile=coverage.out ./...
go tool cover -func=coverage.out
```

## Test Maintenance

### Regular Reviews

- Review test effectiveness quarterly
- Remove redundant tests
- Update tests with code changes
- Monitor test execution time

### Test Documentation

Document complex test scenarios:

```go
// TestComplexScenario verifies that when a pipeline configuration
// contains circular dependencies, the validator detects them and
// returns an appropriate error with details about the cycle.
func TestComplexScenario(t *testing.T) {
    // Test implementation
}
```

### Flaky Test Prevention

- Use deterministic time in tests
- Avoid hardcoded ports
- Clean up resources properly
- Use proper synchronization

```go
// Use fixed time in tests
func TestWithTime(t *testing.T) {
    fixedTime := time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC)
    clock := &mockClock{now: fixedTime}
    
    service := NewServiceWithClock(clock)
    // Test with predictable time
}
```

This comprehensive testing strategy ensures high-quality, reliable software that can be confidently deployed to production.