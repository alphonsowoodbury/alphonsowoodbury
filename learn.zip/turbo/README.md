# Turbo CLI

Turbo is a command-line tool that accelerates data pipeline development by automating the generation of pipeline configuration files from JSON specifications.

## Features

- **Simple Setup**: Configure once with your DPL repository path
- **JSON to Pipeline**: Transform pipeline specifications into properly structured configuration files
- **Environment Support**: Automatically generates dev, staging, and prod configurations
- **DRY Principle**: Write your pipeline spec once, generate all required files

## Installation

```bash
go install github.com/alphonso/turbo/cmd/turbo@latest
```

Or download the latest binary from the releases page.

## Quick Start

1. **Initialize Turbo with your DPL repository:**
   ```bash
   turbo init ~/workspace/data-platform-dpl
   ```

2. **Create a pipeline specification JSON file:**
   ```json
   {
     "name": "customer-analytics",
     "description": "Customer behavior analytics pipeline",
     "type": "batch",
     "schedule": "0 2 * * *",
     "source": {
       "type": "s3",
       "bucket": "raw-data",
       "prefix": "customers/"
     },
     "destination": {
       "type": "redshift",
       "schema": "analytics",
       "table": "customer_metrics"
     }
   }
   ```

3. **Generate pipeline files:**
   ```bash
   turbo generate customer-analytics.json
   ```

4. **Commit and push your changes:**
   ```bash
   cd ~/workspace/data-platform-dpl
   git add .
   git commit -m "Add pipeline: customer-analytics"
   git push
   ```

## Generated File Structure

Running `turbo generate` creates the following files in your DPL repository:

```
dpl-repo/
├── pipelines/
│   └── <pipeline-name>/
│       ├── config.json          # Base configuration
│       ├── config.dev.json      # Development overrides
│       ├── config.staging.json  # Staging overrides
│       └── config.prod.json     # Production overrides
├── deployments/
│   └── <pipeline-name>/
│       └── deployment.yaml      # Kubernetes deployment manifest
└── tests/
    └── <pipeline-name>/
        └── test-config.yaml     # Data quality test configuration
```

## Commands

### `turbo init <dpl-repo-path>`
Initialize Turbo with the path to your Data Platform DPL repository.

### `turbo config`
Display the current configuration, including the DPL repository path.

### `turbo generate <input.json>`
Generate pipeline configuration files from a JSON specification.

Options:
- `--force`: Overwrite existing pipeline files
- `--dry-run`: Preview what files would be created without writing them

### `turbo version`
Display the version information.

## JSON Specification Format

The input JSON should contain:

- `name` (required): Pipeline identifier
- `description`: Human-readable description
- `type`: Pipeline type (batch/streaming), defaults to "batch"
- `schedule`: Cron expression for batch pipelines
- `source`: Source configuration object
- `destination`: Destination configuration object
- `transformations`: Array of transformation steps
- `<env>_overrides`: Environment-specific configuration overrides

## Development

```bash
# Clone the repository
git clone https://github.com/alphonso/turbo.git
cd turbo

# Install dependencies
go mod download

# Build
go build -o turbo cmd/turbo/main.go

# Run
./turbo --help
```

## License

MIT License - see LICENSE file for details.