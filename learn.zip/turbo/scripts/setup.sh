#!/usr/bin/env bash

# Turbo Development Environment Setup Script
# This script sets up a complete development environment for the Turbo project

set -euo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Print colored output
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Detect OS
detect_os() {
    case "$(uname -s)" in
        Darwin*)    OS="macos";;
        Linux*)     OS="linux";;
        CYGWIN*|MINGW*|MSYS*) OS="windows";;
        *)          OS="unknown";;
    esac
    echo "$OS"
}

# Check Go version
check_go_version() {
    if ! command_exists go; then
        print_error "Go is not installed. Please install Go 1.21 or later."
        exit 1
    fi
    
    GO_VERSION=$(go version | awk '{print $3}' | sed 's/go//')
    REQUIRED_VERSION="1.21"
    
    if ! printf '%s\n' "$REQUIRED_VERSION" "$GO_VERSION" | sort -V | head -n1 | grep -q "$REQUIRED_VERSION"; then
        print_error "Go version $GO_VERSION is installed, but version $REQUIRED_VERSION or later is required."
        exit 1
    fi
    
    print_success "Go version $GO_VERSION is installed"
}

# Install development tools
install_tools() {
    print_info "Installing development tools..."
    
    # golangci-lint
    if ! command_exists golangci-lint; then
        print_info "Installing golangci-lint..."
        go install github.com/golangci/golangci-lint/cmd/golangci-lint@latest
    else
        print_success "golangci-lint is already installed"
    fi
    
    # gosec
    if ! command_exists gosec; then
        print_info "Installing gosec..."
        go install github.com/securego/gosec/v2/cmd/gosec@latest
    else
        print_success "gosec is already installed"
    fi
    
    # air for live reload
    if ! command_exists air; then
        print_info "Installing air..."
        go install github.com/cosmtrek/air@latest
    else
        print_success "air is already installed"
    fi
    
    # goimports
    if ! command_exists goimports; then
        print_info "Installing goimports..."
        go install golang.org/x/tools/cmd/goimports@latest
    else
        print_success "goimports is already installed"
    fi
    
    # delve debugger
    if ! command_exists dlv; then
        print_info "Installing delve..."
        go install github.com/go-delve/delve/cmd/dlv@latest
    else
        print_success "delve is already installed"
    fi
    
    # mockgen
    if ! command_exists mockgen; then
        print_info "Installing mockgen..."
        go install github.com/golang/mock/mockgen@latest
    else
        print_success "mockgen is already installed"
    fi
    
    # goreleaser (optional)
    if ! command_exists goreleaser; then
        print_warning "goreleaser is not installed. Install it for release management."
    fi
}

# Setup git hooks
setup_git_hooks() {
    print_info "Setting up git hooks..."
    
    if [ -d .git ]; then
        # Create pre-commit hook
        cat > .git/hooks/pre-commit <<'EOF'
#!/usr/bin/env bash
set -e

echo "Running pre-commit checks..."

# Format check
echo "Checking code formatting..."
if ! make fmt-check; then
    echo "Code is not properly formatted. Run 'make fmt' to fix."
    exit 1
fi

# Lint
echo "Running linter..."
if ! make lint; then
    echo "Linting failed. Fix the issues and try again."
    exit 1
fi

# Run tests
echo "Running tests..."
if ! make test-short; then
    echo "Tests failed. Fix the failing tests and try again."
    exit 1
fi

echo "Pre-commit checks passed!"
EOF
        
        chmod +x .git/hooks/pre-commit
        print_success "Git hooks installed"
    else
        print_warning "Not a git repository. Skipping git hooks setup."
    fi
}

# Create local environment file
create_env_file() {
    if [ ! -f .env ]; then
        print_info "Creating .env file..."
        cat > .env <<'EOF'
# Turbo Local Development Environment

# Application
APP_ENV=development
APP_PORT=8080
APP_HOST=localhost

# Database
DB_HOST=localhost
DB_PORT=5432
DB_USER=turbo
DB_PASSWORD=turbo
DB_NAME=turbo_dev
DB_SSL_MODE=disable

# Redis
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=
REDIS_DB=0

# Logging
LOG_LEVEL=debug
LOG_FORMAT=console

# Development
DEV_MODE=true
EOF
        print_success ".env file created"
    else
        print_success ".env file already exists"
    fi
}

# Setup VS Code
setup_vscode() {
    if command_exists code; then
        print_info "Setting up VS Code..."
        
        mkdir -p .vscode
        
        # Create VS Code settings
        cat > .vscode/settings.json <<'EOF'
{
    "go.lintTool": "golangci-lint",
    "go.lintFlags": [
        "--fast"
    ],
    "go.formatTool": "goimports",
    "go.useLanguageServer": true,
    "go.testFlags": ["-v"],
    "go.testTimeout": "10m",
    "go.coverOnSave": true,
    "go.coverageDecorator": {
        "type": "gutter",
        "coveredHighlightColor": "rgba(64,128,64,0.5)",
        "uncoveredHighlightColor": "rgba(128,64,64,0.5)",
        "coveredGutterStyle": "blockgreen",
        "uncoveredGutterStyle": "blockred"
    },
    "go.coverOnSingleTest": true,
    "[go]": {
        "editor.formatOnSave": true,
        "editor.codeActionsOnSave": {
            "source.organizeImports": true
        }
    },
    "files.watcherExclude": {
        "**/.git/objects/**": true,
        "**/.git/subtree-cache/**": true,
        "**/node_modules/*/**": true,
        "**/vendor/**": true
    },
    "editor.quickSuggestions": {
        "other": true,
        "comments": false,
        "strings": true
    }
}
EOF
        
        # Create launch configuration
        cat > .vscode/launch.json <<'EOF'
{
    "version": "0.2.0",
    "configurations": [
        {
            "name": "Launch Turbo",
            "type": "go",
            "request": "launch",
            "mode": "auto",
            "program": "${workspaceFolder}/cmd/turbo",
            "env": {
                "APP_ENV": "development"
            },
            "args": []
        },
        {
            "name": "Test Current File",
            "type": "go",
            "request": "launch",
            "mode": "test",
            "program": "${file}"
        },
        {
            "name": "Test Current Package",
            "type": "go",
            "request": "launch",
            "mode": "test",
            "program": "${fileDirname}"
        },
        {
            "name": "Attach to Process",
            "type": "go",
            "request": "attach",
            "mode": "local",
            "processId": "${command:pickProcess}"
        }
    ]
}
EOF
        
        print_success "VS Code configuration created"
    else
        print_warning "VS Code CLI not found. Skipping VS Code setup."
    fi
}

# Download dependencies
download_dependencies() {
    print_info "Downloading Go dependencies..."
    go mod download
    go mod verify
    print_success "Dependencies downloaded and verified"
}

# Create necessary directories
create_directories() {
    print_info "Creating project directories..."
    mkdir -p build coverage logs tmp
    print_success "Directories created"
}

# Run initial checks
run_checks() {
    print_info "Running initial checks..."
    
    # Format code
    print_info "Formatting code..."
    make fmt
    
    # Run linter
    print_info "Running linter..."
    if make lint; then
        print_success "Linting passed"
    else
        print_warning "Linting has warnings. Review and fix them."
    fi
    
    # Run tests
    print_info "Running tests..."
    if make test; then
        print_success "Tests passed"
    else
        print_warning "Some tests failed. Review and fix them."
    fi
}

# Main setup function
main() {
    echo "🚀 Turbo Development Environment Setup"
    echo "======================================"
    echo
    
    OS=$(detect_os)
    print_info "Detected OS: $OS"
    
    # Check prerequisites
    check_go_version
    
    # Install tools
    install_tools
    
    # Setup environment
    create_env_file
    create_directories
    download_dependencies
    
    # Setup development environment
    setup_git_hooks
    setup_vscode
    
    # Run initial checks
    run_checks
    
    echo
    echo "======================================"
    print_success "Setup completed successfully! 🎉"
    echo
    echo "Next steps:"
    echo "  1. Review .env file and update configuration"
    echo "  2. Start development with: make dev"
    echo "  3. Run tests with: make test"
    echo "  4. See all commands with: make help"
    echo
    echo "Happy coding! 🚀"
}

# Run main function
main "$@"