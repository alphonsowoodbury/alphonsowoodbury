package cli

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"

	"github.com/alphonso/turbo/internal/config"
	"github.com/alphonso/turbo/internal/generator"
	"github.com/spf13/cobra"
)

func newGenerateCmd() *cobra.Command {
	var force bool
	var dryRun bool

	cmd := &cobra.Command{
		Use:   "generate <input-json>",
		Short: "Generate pipeline files from JSON specification",
		Long: `Generate pipeline configuration files in your DPL repository from a JSON specification.

This command reads a pipeline specification JSON file and creates all necessary 
configuration files in the appropriate directories within your DPL repository.`,
		Args: cobra.ExactArgs(1),
		RunE: func(cmd *cobra.Command, args []string) error {
			// Load configuration
			cfg, err := config.Load()
			if err != nil {
				return fmt.Errorf("failed to load configuration: %w", err)
			}
			
			if cfg.DPLRepoPath == "" {
				return fmt.Errorf("no DPL repository configured. Run 'turbo init <path>' first")
			}
			
			// Read input JSON
			inputFile := args[0]
			data, err := os.ReadFile(inputFile)
			if err != nil {
				return fmt.Errorf("failed to read input file: %w", err)
			}
			
			var spec map[string]interface{}
			if err := json.Unmarshal(data, &spec); err != nil {
				return fmt.Errorf("failed to parse JSON: %w", err)
			}
			
			// Extract pipeline name
			pipelineName, ok := spec["name"].(string)
			if !ok || pipelineName == "" {
				return fmt.Errorf("pipeline 'name' field is required in JSON")
			}
			
			// Check if pipeline already exists
			pipelineDir := filepath.Join(cfg.DPLRepoPath, "pipelines", pipelineName)
			if _, err := os.Stat(pipelineDir); err == nil && !force {
				return fmt.Errorf("pipeline '%s' already exists. Use --force to overwrite", pipelineName)
			}
			
			if dryRun {
				fmt.Println("DRY RUN - Files that would be created:")
			}
			
			// Generate files
			gen := generator.New(cfg.DPLRepoPath)
			if err := gen.GeneratePipeline(spec, dryRun); err != nil {
				return fmt.Errorf("failed to generate pipeline: %w", err)
			}
			
			if !dryRun {
				fmt.Printf("✓ Successfully generated pipeline '%s' in %s\n", pipelineName, cfg.DPLRepoPath)
				fmt.Println("\nNext steps:")
				fmt.Println("  1. cd", cfg.DPLRepoPath)
				fmt.Println("  2. git add .")
				fmt.Println("  3. git commit -m \"Add pipeline:", pipelineName+"\"")
				fmt.Println("  4. git push")
			}
			
			return nil
		},
	}

	cmd.Flags().BoolVar(&force, "force", false, "overwrite existing pipeline")
	cmd.Flags().BoolVar(&dryRun, "dry-run", false, "preview files without creating them")

	return cmd
}