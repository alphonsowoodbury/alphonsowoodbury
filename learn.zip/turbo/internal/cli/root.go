package cli

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"github.com/alphonso/turbo/internal/config"
	"github.com/spf13/cobra"
)

var (
	version = "dev"
	commit  = "none"
	date    = "unknown"

	debug   bool
	envName string
)

var rootCmd = &cobra.Command{
	Use:   "turbo",
	Short: "Accelerate data pipeline development",
	Long: `Turbo is a CLI tool that eliminates friction in data pipeline development.

It automates pipeline artifact generation, streamlines service discovery,
and provides unified access to data platform capabilities.`,
	SilenceUsage:  true,
	SilenceErrors: true,
}

func Execute() error {
	return rootCmd.Execute()
}

func init() {
	rootCmd.PersistentFlags().BoolVar(&debug, "debug", false, "enable debug logging")
	rootCmd.PersistentFlags().StringVar(&envName, "env", "dev", "environment (dev, uat, prod)")

	rootCmd.AddCommand(
		newInitCmd(),
		newConfigCmd(),
		newGenerateCmd(),
		newVersionCmd(),
	)
}

func newVersionCmd() *cobra.Command {
	return &cobra.Command{
		Use:   "version",
		Short: "Print version information",
		Run: func(cmd *cobra.Command, args []string) {
			fmt.Printf("turbo version %s (commit: %s, built: %s)\n", version, commit, date)
		},
	}
}

func newInitCmd() *cobra.Command {
	return &cobra.Command{
		Use:   "init <dpl-repo-path>",
		Short: "Initialize turbo with your DPL repository path",
		Args:  cobra.ExactArgs(1),
		RunE: func(cmd *cobra.Command, args []string) error {
			dplPath := args[0]
			
			// Expand home directory if needed
			if strings.HasPrefix(dplPath, "~") {
				home, err := os.UserHomeDir()
				if err != nil {
					return fmt.Errorf("failed to get home directory: %w", err)
				}
				dplPath = filepath.Join(home, dplPath[2:])
			}
			
			// Convert to absolute path
			absPath, err := filepath.Abs(dplPath)
			if err != nil {
				return fmt.Errorf("failed to get absolute path: %w", err)
			}
			
			// Verify the directory exists
			if stat, err := os.Stat(absPath); err != nil {
				if os.IsNotExist(err) {
					return fmt.Errorf("DPL repository path does not exist: %s", absPath)
				}
				return fmt.Errorf("failed to access DPL repository: %w", err)
			} else if !stat.IsDir() {
				return fmt.Errorf("DPL repository path is not a directory: %s", absPath)
			}
			
			cfg := &config.Config{
				DPLRepoPath: absPath,
			}
			
			if err := config.Save(cfg); err != nil {
				return fmt.Errorf("failed to save configuration: %w", err)
			}
			
			fmt.Printf("✓ Initialized turbo with DPL repository: %s\n", absPath)
			return nil
		},
	}
}

func newConfigCmd() *cobra.Command {
	return &cobra.Command{
		Use:   "config",
		Short: "Show current configuration",
		RunE: func(cmd *cobra.Command, args []string) error {
			cfg, err := config.Load()
			if err != nil {
				return fmt.Errorf("failed to load configuration: %w", err)
			}
			
			if cfg.DPLRepoPath == "" {
				fmt.Println("No DPL repository configured. Run 'turbo init <path>' to set one.")
				return nil
			}
			
			fmt.Printf("DPL Repository: %s\n", cfg.DPLRepoPath)
			return nil
		},
	}
}