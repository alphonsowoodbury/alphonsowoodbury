package generator

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"

	"gopkg.in/yaml.v3"
)

// Generator handles pipeline file generation
type Generator struct {
	dplRepoPath string
}

// New creates a new generator instance
func New(dplRepoPath string) *Generator {
	return &Generator{
		dplRepoPath: dplRepoPath,
	}
}

// GeneratePipeline generates all pipeline files from the specification
func (g *Generator) GeneratePipeline(spec map[string]interface{}, dryRun bool) error {
	pipelineName, _ := spec["name"].(string)
	
	// Define files to generate
	files := []struct {
		path    string
		content interface{}
		format  string // "json" or "yaml"
	}{
		// Pipeline configurations
		{
			path:    filepath.Join("pipelines", pipelineName, "config.json"),
			content: g.generateBaseConfig(spec),
			format:  "json",
		},
		{
			path:    filepath.Join("pipelines", pipelineName, "config.dev.json"),
			content: g.generateEnvConfig(spec, "dev"),
			format:  "json",
		},
		{
			path:    filepath.Join("pipelines", pipelineName, "config.staging.json"),
			content: g.generateEnvConfig(spec, "staging"),
			format:  "json",
		},
		{
			path:    filepath.Join("pipelines", pipelineName, "config.prod.json"),
			content: g.generateEnvConfig(spec, "prod"),
			format:  "json",
		},
		// Deployment configuration
		{
			path:    filepath.Join("deployments", pipelineName, "deployment.yaml"),
			content: g.generateDeploymentConfig(spec),
			format:  "yaml",
		},
		// Test configuration
		{
			path:    filepath.Join("tests", pipelineName, "test-config.yaml"),
			content: g.generateTestConfig(spec),
			format:  "yaml",
		},
	}
	
	// Generate each file
	for _, file := range files {
		fullPath := filepath.Join(g.dplRepoPath, file.path)
		
		if dryRun {
			fmt.Printf("  %s\n", file.path)
			continue
		}
		
		// Create directory if needed
		dir := filepath.Dir(fullPath)
		if err := os.MkdirAll(dir, 0755); err != nil {
			return fmt.Errorf("failed to create directory %s: %w", dir, err)
		}
		
		// Marshal content based on format
		var data []byte
		var err error
		
		switch file.format {
		case "json":
			data, err = json.MarshalIndent(file.content, "", "  ")
		case "yaml":
			data, err = yaml.Marshal(file.content)
		default:
			return fmt.Errorf("unknown format: %s", file.format)
		}
		
		if err != nil {
			return fmt.Errorf("failed to marshal %s: %w", file.path, err)
		}
		
		// Write file
		if err := os.WriteFile(fullPath, data, 0644); err != nil {
			return fmt.Errorf("failed to write %s: %w", file.path, err)
		}
	}
	
	return nil
}

// generateBaseConfig generates the base configuration
func (g *Generator) generateBaseConfig(spec map[string]interface{}) map[string]interface{} {
	config := map[string]interface{}{
		"name":        spec["name"],
		"description": spec["description"],
		"version":     "1.0.0",
		"type":        getOrDefault(spec, "type", "batch"),
		"schedule":    getOrDefault(spec, "schedule", "0 0 * * *"),
	}
	
	// Add source configuration
	if source, ok := spec["source"].(map[string]interface{}); ok {
		config["source"] = source
	}
	
	// Add destination configuration
	if destination, ok := spec["destination"].(map[string]interface{}); ok {
		config["destination"] = destination
	}
	
	// Add transformations if present
	if transformations, ok := spec["transformations"]; ok {
		config["transformations"] = transformations
	}
	
	return config
}

// generateEnvConfig generates environment-specific configuration
func (g *Generator) generateEnvConfig(spec map[string]interface{}, env string) map[string]interface{} {
	envConfig := map[string]interface{}{
		"environment": env,
		"resources": map[string]interface{}{
			"cpu":    getEnvResource(env, "cpu", "0.5", "1", "2"),
			"memory": getEnvResource(env, "memory", "512Mi", "1Gi", "2Gi"),
		},
		"scaling": map[string]interface{}{
			"minInstances": getEnvResource(env, "minInstances", 1, 2, 3),
			"maxInstances": getEnvResource(env, "maxInstances", 2, 5, 10),
		},
	}
	
	// Add environment-specific overrides if present
	if envOverrides, ok := spec[env+"_overrides"].(map[string]interface{}); ok {
		for k, v := range envOverrides {
			envConfig[k] = v
		}
	}
	
	return envConfig
}

// generateDeploymentConfig generates deployment configuration
func (g *Generator) generateDeploymentConfig(spec map[string]interface{}) map[string]interface{} {
	pipelineName, _ := spec["name"].(string)
	
	return map[string]interface{}{
		"apiVersion": "apps/v1",
		"kind":       "Deployment",
		"metadata": map[string]interface{}{
			"name":      pipelineName,
			"namespace": "data-pipelines",
			"labels": map[string]interface{}{
				"app":      pipelineName,
				"team":     "data-engineering",
				"pipeline": pipelineName,
			},
		},
		"spec": map[string]interface{}{
			"replicas": 1,
			"selector": map[string]interface{}{
				"matchLabels": map[string]interface{}{
					"app": pipelineName,
				},
			},
			"template": map[string]interface{}{
				"metadata": map[string]interface{}{
					"labels": map[string]interface{}{
						"app": pipelineName,
					},
				},
				"spec": map[string]interface{}{
					"containers": []map[string]interface{}{
						{
							"name":  pipelineName,
							"image": fmt.Sprintf("data-platform/%s:latest", pipelineName),
							"env": []map[string]interface{}{
								{
									"name":  "PIPELINE_NAME",
									"value": pipelineName,
								},
								{
									"name": "ENVIRONMENT",
									"valueFrom": map[string]interface{}{
										"fieldRef": map[string]interface{}{
											"fieldPath": "metadata.namespace",
										},
									},
								},
							},
						},
					},
				},
			},
		},
	}
}

// generateTestConfig generates test configuration
func (g *Generator) generateTestConfig(spec map[string]interface{}) map[string]interface{} {
	return map[string]interface{}{
		"tests": []map[string]interface{}{
			{
				"name":        "data_quality_check",
				"type":        "quality",
				"enabled":     true,
				"description": "Validate data quality metrics",
				"rules": []map[string]interface{}{
					{
						"name":      "null_check",
						"columns":   []string{"id", "timestamp"},
						"condition": "not_null",
					},
					{
						"name":      "range_check",
						"columns":   []string{"amount"},
						"condition": "between",
						"min":       0,
						"max":       1000000,
					},
				},
			},
			{
				"name":        "schema_validation",
				"type":        "schema",
				"enabled":     true,
				"description": "Validate output schema",
			},
		},
	}
}

// Helper functions

func getOrDefault(spec map[string]interface{}, key string, defaultValue interface{}) interface{} {
	if value, ok := spec[key]; ok {
		return value
	}
	return defaultValue
}

func getEnvResource(env, resource string, dev, staging, prod interface{}) interface{} {
	switch env {
	case "dev":
		return dev
	case "staging":
		return staging
	case "prod":
		return prod
	default:
		return dev
	}
}